#!/usr/bin/env bash
# Is folder ki poori state GitHub par bhejta hai (purani files bhi hatati hai).
# Pehle saare badlav dikhata hai, phir aapse poochta hai. Bina 'y' ke kuch nahi bhejta.
#   ./scripts/publish_to_github.sh
# Env (optional): REMOTE, BRANCH, MSG, GIT_NAME, GIT_EMAIL
set -euo pipefail
REMOTE="${REMOTE:-https://github.com/ganpatiengineers007-ux/Strategy-Backtesting.git}"
BRANCH="${BRANCH:-main}"
MSG="${MSG:-Sync: reorganized layout, study pipeline, results store, dashboard, login, strategy names}"
SRC="$(cd "$(dirname "$0")/.." && pwd)"

for f in config/users.json output/results.db .env fyers_hub/.env; do
  if [ -e "$SRC/$f" ]; then
    echo "ROKA: $f is folder me hai. Ye GitHub par nahi jana chahiye. Pehle hatayein ya bahar rakhein."
    exit 1
  fi
done
secret_files=$(find "$SRC" -name "*.env" ! -name "*.example" -not -path "*/.git/*")
if [ -n "$secret_files" ]; then
  echo "ROKA: ye .env files mili, GitHub par nahi jayengi:"; echo "$secret_files"; exit 1
fi

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
git clone -q "$REMOTE" "$WORK/repo"
cd "$WORK/repo"
if git show-ref --verify --quiet "refs/remotes/origin/$BRANCH"; then
  git checkout -q -B "$BRANCH" "origin/$BRANCH"
else
  git checkout -q -b "$BRANCH"
fi

find . -mindepth 1 -maxdepth 1 ! -name .git -exec rm -rf {} +
cp -a "$SRC"/. .
find . -name __pycache__ -prune -exec rm -rf {} +
git add -A

echo "================ GitHub par ye badlav honge ================"
git status --short | head -300
echo "============================================================"
echo "Total badlav: $(git status --short | wc -l)"
read -r -p "Push karein? (y/N): " ans
if [ "$ans" != "y" ] && [ "$ans" != "Y" ]; then
  echo "Ruk gaya. Kuch nahi bheja gaya."
  exit 0
fi

if git diff --cached --quiet; then
  echo "Koi badlav nahi hai."
  exit 0
fi
git -c user.name="${GIT_NAME:-Strategy Sync}" -c user.email="${GIT_EMAIL:-sync@localhost}" commit -q -m "$MSG"
git push -q origin "$BRANCH"
echo "Push ho gaya: $REMOTE ($BRANCH)"
