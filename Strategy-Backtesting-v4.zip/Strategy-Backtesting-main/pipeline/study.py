"""Study runner: har strategy ko har dataset (purana + naya) par chalao, metrics + validation + gates + score,
phir pass hone wali strategies ko gts_export/ me package karo (GTS me baad me daalne ke liye)."""
import csv
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

import yaml

from backend.services.backtest_service import load_config
from backtest.engine import run_backtest
from data.loaders import load_dataset
from metrics import compute_all
from pipeline.gates import DEFAULT_GATES, DEFAULT_WEIGHTS, composite_scores, evaluate_gates
from registry import compatibility
from registry.metadata import load_manifest
from registry.registry import Registry
from strategies.validation import validate_manifest
from validation.pipeline import run_validation

ROOT = Path(__file__).resolve().parents[1]
METRIC_KEYS = ["n_trades", "win_rate_pct", "expectancy", "total_return_pct", "max_drawdown_pct", "sharpe_daily"]
SUMMARY_COLS = ["rank", "strategy_id", "version", "STUDY_RESULT", "score", "datasets_run", "datasets_passed",
                "n_trades", "win_rate_pct", "expectancy", "total_return_pct", "max_drawdown_pct", "sharpe_daily",
                "validation", "failures", "export_warnings"]


def load_study_config(path=None):
    p = Path(path) if path else ROOT / "config" / "study.yaml"
    return yaml.safe_load(p.read_text(encoding="utf-8")) or {} if p.exists() else {}


def discover_safe(strategies_dir):
    """Ek kharab manifest pure system ko nahi rokta (Registry.discover() rokta hai). Returns (registry, errors)."""
    sdir = Path(strategies_dir)
    reg = Registry(sdir)
    errors = {}
    for d in sorted(sdir.iterdir()):
        mf = d / "manifest.yaml"
        if not (d.is_dir() and mf.exists()):
            continue
        try:
            m = load_manifest(mf)
            errs = validate_manifest(m) + compatibility.check(m)
            if errs:
                raise ValueError("; ".join(map(str, errs)))
            reg.records[m["id"]] = {"manifest": m, "dir": d}
        except Exception as e:  # noqa: BLE001 - ek strategy ki galti ko pure run ka fail nahi banana
            errors[d.name] = f"{type(e).__name__}: {e}"
    return reg, errors


SHARED_FILES = ["strategies/__init__.py", "strategies/base.py", "strategies/models.py", "strategies/context.py",
                "strategies/validation.py", "strategies/_bridge.py", "registry/__init__.py"]


def _scan_deps(strategy_dir):
    """Strategy ke code me bahar ki nirbharta dhundho. Returns (warnings, needs_external, needs_greeks)."""
    warns, ext, greeks = [], False, False
    for f in Path(strategy_dir).rglob("*.py"):
        if f.is_symlink():
            continue
        text = f.read_text(encoding="utf-8", errors="ignore")
        if "external" in text and "_EXTERNAL_ROOT" in text:
            ext = True
            warns.append(f"{f.name}: external/ code par nirbhar")
        if "all_strategies" in text:
            greeks = True
            warns.append(f"{f.name}: all_strategies/greeks core code par nirbhar")
    return sorted(set(warns)), ext, greeks


def _bundle(dst, strategy_dir, needs_external, needs_greeks):
    """Export ko mini-repo ke roop me likho: wahi relative paths, taaki adapter ke sys.path hack GTS me bhi chalein."""
    copied = []
    ignore = shutil.ignore_patterns("__pycache__", "*.pyc")

    def cp(rel):
        src = ROOT / rel
        if not src.exists():
            return
        target = dst / rel
        if src.is_dir():
            shutil.copytree(src, target, ignore=ignore, symlinks=False, dirs_exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, target)
        copied.append(rel)

    for rel in SHARED_FILES:
        cp(rel)
    try:
        strat_rel = Path(strategy_dir).resolve().relative_to(ROOT.resolve())
    except ValueError:
        strat_rel = Path("strategies") / Path(strategy_dir).name
    cp(str(strat_rel))
    if needs_external:
        cp("external")
    if needs_greeks:
        cp("all_strategies/greeks")
    return copied


def evaluate_one(reg, sid, ds, cfg, validate):
    factory = lambda: reg.load(sid)  # noqa: E731
    run = {"strategy_id": sid, "dataset_id": ds.dataset_id, "dataset_hash": ds.content_hash,
           "bars": len(ds.bars), "version": str(reg.manifest(sid).get("version", ""))}
    result = run_backtest(ds, factory(), cfg)
    run["reason"] = result.reason
    if result.status == "BLOCKED":
        run.update(status="BLOCKED", metrics={}, validation_status="BLOCKED", validation_checks={})
        return run
    run["status"] = result.status
    run["metrics"] = compute_all(result, ds)
    if validate:
        val = run_validation(ds, factory, cfg)
        run["validation_status"] = val["status"]
        run["validation_checks"] = {k: (v.get("status") if isinstance(v, dict) else v)
                                    for k, v in val.get("checks", {}).items()}
    else:
        run["validation_status"] = "SKIPPED"
        run["validation_checks"] = {}
    return run


def _mean(vals):
    vals = [float(v) for v in vals if v is not None]
    return round(sum(vals) / len(vals), 4) if vals else None


def aggregate(sid, runs, gates):
    """Ek strategy ke sabhi dataset-runs ko ek row me. Pass = har dataset pass (require_all_datasets)."""
    passed = [r for r in runs if r["gate_pass"]]
    all_pass = len(passed) == len(runs) and runs
    overall_pass = bool(all_pass) if gates.get("require_all_datasets", True) else bool(passed)
    fails = sorted({f"[{r['dataset_id']}] {x}" for r in runs for x in r["gate_failures"]})
    agg = {k: _mean([r["metrics"].get(k) for r in runs if r.get("metrics")]) for k in METRIC_KEYS}
    if agg.get("max_drawdown_pct") is not None:
        agg["max_drawdown_pct"] = round(abs(agg["max_drawdown_pct"]), 4)
    trades_sum = sum(int(r["metrics"].get("n_trades", 0)) for r in runs if r.get("metrics"))
    agg["n_trades"] = trades_sum
    vals = [r.get("validation_status") for r in runs]
    worst = next((s for s in ("ERROR", "FAIL", "BLOCKED", "INCOMPLETE", "SKIPPED") if s in vals), "PASS")
    return {"strategy_id": sid, "version": runs[0].get("version", ""), "metrics": agg,
            "STUDY_RESULT": "PASS" if overall_pass else "FAIL", "datasets_run": len(runs),
            "datasets_passed": len(passed), "validation": worst,
            "failures": "; ".join(fails)[:1000]}


def run_study(data_dir=None, out_root=None, study_config=None, strategies_dir=None,
              validate=True, strategy_ids=None, datasets=None):
    cfg_all = load_study_config(study_config)
    gates = {**DEFAULT_GATES, **(cfg_all.get("gates") or {})}
    weights = {**DEFAULT_WEIGHTS, **(cfg_all.get("score_weights") or {})}
    engine_cfg = load_config()
    engine_cfg.update(cfg_all.get("engine") or {})

    sdir = Path(strategies_dir) if strategies_dir else ROOT / "strategies"
    reg, load_errors = discover_safe(sdir)
    sids = sorted(strategy_ids) if strategy_ids else sorted(reg.records)
    if not sids:
        raise SystemExit(f"koi valid strategy nahi mili ({sdir}); load errors: {load_errors}")

    ddir = Path(data_dir or cfg_all.get("datasets_dir") or ROOT / "data" / "hub_export")
    files = [Path(p) for p in datasets] if datasets else sorted(
        [p for p in ddir.glob("*") if p.suffix.lower() in {".csv", ".parquet"}])
    if not files:
        raise SystemExit(f"{ddir} me koi CSV/parquet nahi. Pehle: python -m cli.main hub-export")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    out_dir = Path(out_root or ROOT / "output" / "study") / f"study-{stamp}"
    out_dir.mkdir(parents=True, exist_ok=True)

    runs, errors = [], []
    for dp in files:
        try:
            ds = load_dataset(dp, dataset_id=dp.stem)
        except Exception as e:  # noqa: BLE001
            errors.append({"dataset": dp.name, "error": f"{type(e).__name__}: {e}"})
            continue
        for sid in sids:
            try:
                r = evaluate_one(reg, sid, ds, engine_cfg, validate)
            except Exception as e:  # noqa: BLE001
                r = {"strategy_id": sid, "dataset_id": ds.dataset_id, "dataset_hash": ds.content_hash, "bars": len(ds.bars),
                     "status": "ERROR", "reason": f"{type(e).__name__}: {e}", "metrics": {},
                     "validation_status": "ERROR", "validation_checks": {}, "version": ""}
            ok, fails = evaluate_gates(r, gates)
            r["gate_pass"], r["gate_failures"] = ok, fails
            runs.append(r)

    by_sid = {}
    for r in runs:
        by_sid.setdefault(r["strategy_id"], []).append(r)
    rows = [aggregate(sid, by_sid[sid], gates) for sid in sids if sid in by_sid]
    scores = composite_scores([{"strategy_id": r["strategy_id"], "metrics": r["metrics"]} for r in rows], weights)
    for r in rows:
        r["score"] = scores.get(r["strategy_id"])
    rows.sort(key=lambda r: (r["STUDY_RESULT"] != "PASS", -(r["score"] if r["score"] is not None else -1)))
    for i, r in enumerate(rows, 1):
        r["rank"] = i
        r["export_warnings"] = []

    exported = []
    for r in rows:
        if r["STUDY_RESULT"] != "PASS":
            continue
        src = Path(reg.records[r["strategy_id"]]["dir"])  # folder naam manifest id se alag ho sakta hai
        dst = out_dir / "gts_export" / r["strategy_id"]
        dst.mkdir(parents=True, exist_ok=True)
        warns, need_ext, need_gr = _scan_deps(src)
        r["export_warnings"] = warns
        bundle = _bundle(dst, src, need_ext, need_gr)
        manifest = {"strategy_id": r["strategy_id"], "version": r["version"], "study_id": out_dir.name,
                    "source_hash": reg.source_hash(r["strategy_id"]), "score": r["score"], "gates": gates,
                    "metrics": r["metrics"], "datasets": sorted({x["dataset_id"] + ":" + x["dataset_hash"][:12]
                                                                  for x in by_sid[r["strategy_id"]]}),
                    "bundle_paths": bundle, "export_warnings": warns,
                    "exported_at": datetime.now(timezone.utc).isoformat()}
        (dst / "export_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False, default=str),
                                                  encoding="utf-8")
        exported.append(r["strategy_id"])

    with open(out_dir / "summary.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=SUMMARY_COLS, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({**r, **r["metrics"], "export_warnings": " | ".join(r["export_warnings"])})
    (out_dir / "summary.json").write_text(json.dumps({"study_id": out_dir.name, "gates": gates, "weights": weights,
                                                     "datasets": [p.name for p in files], "strategies": rows,
                                                     "exported": exported}, indent=2, ensure_ascii=False, default=str),
                                          encoding="utf-8")
    (out_dir / "runs.json").write_text(json.dumps(runs, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    (out_dir / "load_errors.json").write_text(json.dumps({"strategies": load_errors, "datasets": errors},
                                                         indent=2, ensure_ascii=False), encoding="utf-8")
    from results import store
    conn = store.connect()
    store.record_study(conn, out_dir.name, datetime.now(timezone.utc).isoformat(), gates, weights,
                       [p.name for p in files], out_dir, rows, runs)
    conn.close()
    return {"out_dir": str(out_dir), "rows": rows, "exported": exported, "load_errors": load_errors,
            "dataset_errors": errors}


def print_table(rows):
    head = f"{'#':>2} {'STRATEGY':<24} {'RESULT':<6} {'SCORE':>6} {'TRADES':>6} {'ACC%':>6} {'EXPECT':>9} {'RET%':>8} {'MDD%':>7} {'SHARPE':>7} {'VALID':<10}"
    print(head)
    print("-" * len(head))
    for r in rows:
        m = r["metrics"]
        f = lambda v, p=2: "-" if v is None else f"{v:.{p}f}"  # noqa: E731
        print(f"{r['rank']:>2} {r['strategy_id']:<24} {r['STUDY_RESULT']:<6} {f(r['score'],3):>6} {m.get('n_trades', 0):>6} "
              f"{f(m.get('win_rate_pct'),1):>6} {f(m.get('expectancy')):>9} {f(m.get('total_return_pct')):>8} "
              f"{f(m.get('max_drawdown_pct')):>7} {f(m.get('sharpe_daily')):>7} {r['validation']:<10}")
