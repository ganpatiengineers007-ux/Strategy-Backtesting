import csv
import json
import random
from datetime import date, timedelta
from pathlib import Path

from backend.services.backtest_service import load_config, run_full
from data.loaders import load_dataset
from optimization import parameter_search
from optimization.constraints import DEFAULT_RULES
from registry.registry import Registry


def make_sample_csv(path, days=120, seed=42):
    """Deterministic random-walk 5-min bars (sirf demo, asli data nahi)."""
    rng, price, d, rows = random.Random(seed), 1000.0, date(2024, 1, 1), []
    while len(rows) < days * 75:
        if d.weekday() < 5:
            for i in range(75):
                mins = 9 * 60 + 15 + i * 5
                o = price
                c = max(1.0, o * (1 + rng.gauss(0, 0.0008)))
                rows.append([f"{d.isoformat()}T{mins // 60:02d}:{mins % 60:02d}:00", round(o, 2),
                             round(max(o, c) * (1 + abs(rng.gauss(0, 0.0004))), 2),
                             round(min(o, c) * (1 - abs(rng.gauss(0, 0.0004))), 2), round(c, 2), rng.randint(100, 5000)])
                price = c
        d += timedelta(days=1)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["ts", "open", "high", "low", "close", "volume"])
        w.writerows(rows)
    return str(path)


def cmd_list(_args):
    for sid in Registry().discover():
        print(sid)


def cmd_run(args):
    record, paths = run_full(args.strategy, args.data, out_root=args.out)
    print(f"status={record['status']} validation={record['validation_status']} reason={record['reason']}")
    print("report:", paths["html"])


def cmd_demo(args):
    csv_path = make_sample_csv(Path(args.out) / "sample_5m.csv")
    for sid in ("three_pm_momentum", "gamma_blast"):
        record, paths = run_full(sid, csv_path, out_root=args.out, symbol="DEMO", timeframe="5m")
        print(f"[{sid}] status={record['status']} validation={record['validation_status']} {record['reason']}")
        print("   report:", paths["html"])


def cmd_optimize(args):
    reg = Registry()
    ds = load_dataset(args.data)
    out = parameter_search.search(ds, lambda p: reg.load(args.strategy, p), json.loads(args.grid), load_config(),
                                  rules=DEFAULT_RULES, track_root=args.out, experiment_id=args.strategy)
    print(f"status={out['status']} trials={out['n_trials']} {out.get('reason', '')}")
    if "best_params" in out:
        print("best:", out["best_params"], "holdout_trades:", out["holdout_trades"],
              "holdout_expectancy:", round(out["holdout_expectancy"], 2))
    print(out.get("warning", ""))


def cmd_sample(args):
    print("written:", make_sample_csv(args.out, days=args.days))


def _default_hub_db():
    """fyers_hub ke settings jaisa hi: HUB_DB_PATH, warna FYERS_HUB_HOME (default ~/.fyers_hub)/hub.db"""
    import os
    return os.getenv("HUB_DB_PATH") or str(Path(os.getenv("FYERS_HUB_HOME", str(Path.home() / ".fyers_hub"))) / "hub.db")


def cmd_hub_export(args):
    from pipeline.hub_export import export_all
    res = export_all(args.db or _default_hub_db(), args.out, tf=args.tf, symbol=args.symbol, tz=args.tz)
    if not res:
        print("hub me koi candles nahi mile (filter check karo: --tf / --symbol). Pehle fyers_hub backfill chalao.")
        return
    for r in res:
        print(f"{r['rows']:>9} rows  {r['symbol']} [{r['tf']}] -> {r['path']}")
    print(f"done: {len(res)} file(s) in {args.out}")


def cmd_study(args):
    from pipeline.study import print_table, run_study
    res = run_study(data_dir=args.data_dir, out_root=args.out, study_config=args.config,
                    validate=not args.no_validate, strategy_ids=args.strategy or None)
    print_table(res["rows"])
    print()
    print("PASS (export ho gayi):", ", ".join(res["exported"]) or "koi nahi")
    if res["load_errors"]:
        print("strategy load errors:", res["load_errors"])
    if res["dataset_errors"]:
        print("dataset errors:", res["dataset_errors"])
    print("report folder:", res["out_dir"])


def cmd_history(args):
    from results import store
    conn = store.connect()
    if args.strategy:
        rows = store.strategy_history(conn, args.strategy)
        if not rows:
            print(f"{args.strategy}: koi run nahi mila")
        for r in rows:
            print(f"{r['created_at'][:19]}  {r['study_id']}  {r['study_result']:<5} "
                  f"trades={r['n_trades']} acc={r['win_rate_pct']} ret%={r['total_return_pct']} "
                  f"mdd%={r['max_drawdown_pct']} sharpe={r['sharpe_daily']} valid={r['validation']}")
    else:
        for r in store.all_latest(conn):
            print(f"{r['strategy_id']:<22} {r['study_result']:<5} ret%={r['total_return_pct']} acc={r['win_rate_pct']} "
                  f"trades={r['n_trades']} (study {r['study_id']})")
    conn.close()
