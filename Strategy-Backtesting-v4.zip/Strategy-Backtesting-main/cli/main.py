"""CLI: python -m cli.main {demo|list|run|optimize|make-sample|hub-export|study}"""
import argparse
import sys

from cli import commands


def main(argv=None):
    ap = argparse.ArgumentParser(prog="svl")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list").set_defaults(fn=commands.cmd_list)
    d = sub.add_parser("demo")
    d.add_argument("--out", default="runs")
    d.set_defaults(fn=commands.cmd_demo)
    r = sub.add_parser("run")
    r.add_argument("--strategy", required=True)
    r.add_argument("--data", required=True)
    r.add_argument("--out", default="runs")
    r.set_defaults(fn=commands.cmd_run)
    o = sub.add_parser("optimize")
    o.add_argument("--strategy", required=True)
    o.add_argument("--data", required=True)
    o.add_argument("--grid", required=True, help='JSON: {"stop_pct":[0.3,0.5],"target_pct":[0.8,1.0]}')
    o.add_argument("--out", default="runs")
    o.set_defaults(fn=commands.cmd_optimize)
    s = sub.add_parser("make-sample")
    s.add_argument("--out", default="data/samples/sample_5m.csv")
    s.add_argument("--days", type=int, default=120)
    s.set_defaults(fn=commands.cmd_sample)

    h = sub.add_parser("hub-export", help="Fyers hub (SQLite) se backtest CSV banao")
    h.add_argument("--db", default=None, help="default: $HUB_DB_PATH, warna $FYERS_HUB_HOME/hub.db (default ~/.fyers_hub)")
    h.add_argument("--tf", default=None, help="jaise 5, 15, 60, D (default: sabhi)")
    h.add_argument("--symbol", default=None, help="ek symbol hi chahiye to")
    h.add_argument("--out", default="data/hub_export")
    h.add_argument("--tz", default="Asia/Kolkata")
    h.set_defaults(fn=commands.cmd_hub_export)

    st = sub.add_parser("study", help="sabhi strategies x sabhi datasets: metrics, gates, score, export")
    st.add_argument("--data-dir", default=None, help="default: config/study.yaml -> datasets_dir")
    st.add_argument("--out", default="output/study")
    st.add_argument("--config", default=None, help="default: config/study.yaml")
    st.add_argument("--strategy", action="append", help="sirf ye strategy (baar-baar de sakte ho)")
    st.add_argument("--no-validate", action="store_true", help="validation skip (tez, lekin export se pehle na karo)")
    st.set_defaults(fn=commands.cmd_study)

    hi = sub.add_parser("history", help="strategy ka poora itihaas (ya har strategy ka latest)")
    hi.add_argument("--strategy", default=None)
    hi.set_defaults(fn=commands.cmd_history)

    args = ap.parse_args(argv)
    args.fn(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
