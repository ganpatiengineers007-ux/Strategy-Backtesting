"""Strategy ka display naam: ek baar tay, kabhi nahi badalta, kabhi dobara nahi diya jata.
Ledger: config/strategy_names.json  ->  {"assigned": {"<id>": "<naam>"}, "pool": [...]}
ID (jaise `fvg`) technical key hai; naam sirf dikhane ke liye hai."""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEDGER = ROOT / "config" / "strategy_names.json"
ID_RE = re.compile(r"^[a-z][a-z0-9_]{2,39}$")

POOL = [
    "Ganpati", "Gajanan", "Vighnaharta", "Siddhivinayak", "Ekdanta", "Lambodar", "Vakratunda", "Mangalmurti",
    "Gananayak", "Shubhankar", "Vinayak", "Dhoomketu", "Balganesh", "Ganadhyaksha", "Modak", "Pranav",
    "Govind", "Madhav", "Keshav", "Murari", "Gopal", "Mohan", "Vasudev", "Kanha", "Damodar", "Hari",
    "Narayan", "Shyam", "Giridhar", "Madhusudan", "Achyut", "Janardan", "Yaduvir", "Nandlal", "Girdhari",
    "Mukund", "Gopinath", "Bansidhar", "Rasik", "Dwarkesh", "Pundarik", "Ranchhod", "Kamalnayan", "Jagdish",
    "Govardhan", "Madhukar", "Shrinath", "Vrajesh", "Yogeshwar", "Sudarshan", "Partha", "Kesari", "Shivam",
    "Ramesh", "Surya", "Chandra", "Agni", "Varun", "Indra", "Vayu", "Prithvi", "Akash", "Dhruv",
]


def load():
    if LEDGER.exists():
        return json.loads(LEDGER.read_text(encoding="utf-8"))
    return {"assigned": {}, "pool": list(POOL)}


def _save(data):
    LEDGER.parent.mkdir(parents=True, exist_ok=True)
    LEDGER.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def validate_id(sid):
    if not ID_RE.match(sid):
        raise ValueError(f"strategy id galat hai: '{sid}' (chhote akshar, underscore, 3-40 akshar)")
    return sid


def assign_all(strategy_ids):
    """Har id ko naam do. Jo pehle se hai woh wahi rahega. Naya id -> pool ka agla unused naam."""
    data = load()
    used = set(data["assigned"].values())
    for sid in strategy_ids:
        validate_id(sid)
        if sid in data["assigned"]:
            continue
        free = [n for n in data["pool"] if n not in used]
        if not free:
            raise RuntimeError("naam pool khatam. config/strategy_names.json me naam badhao (pool me naye naam jodo)")
        data["assigned"][sid] = free[0]
        used.add(free[0])
    _save(data)
    return {sid: data["assigned"][sid] for sid in strategy_ids}
