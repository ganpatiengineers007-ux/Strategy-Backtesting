"""GTS-GEMINI-PRO-01 (liquidity trap) registry wrapper.

Engine ka core: core/gemini_pro_01.py (ek-file script, Pydroid ke liye bana tha, ab repo me).
Is strategy ko har candle par aggressive buy/sell volume (ask_aggr, bid_aggr) aur har din
prev-day delivery volume chahiye. Hub me ye data abhi nahi hai, isliye engine ise BLOCKED dikhata hai.
Jab data aayega, is adapter ko core engine se jodna hoga; tab tak yeh saaf error deta hai.
"""
from strategies.base import Strategy
from strategies._bridge import not_wired


class GeminiPro01Adapter(Strategy):
    strategy_id = "gemini_pro_01"
    required_data = ("ask_aggr", "bid_aggr")

    def on_bar(self, ctx):
        return not_wired(self.strategy_id, self.required_data)
