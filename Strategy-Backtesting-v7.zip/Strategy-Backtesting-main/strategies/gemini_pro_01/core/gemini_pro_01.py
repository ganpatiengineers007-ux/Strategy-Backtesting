#!/usr/bin/env python3
# ============================================================
#  GTS-GEMINI-PRO-01 — INSTITUTIONAL LIQUIDITY TRAP STRATEGY
#  Idea by: Jamuna | Engine: GTS-GEMINI PRO Core
#  Target env: Pydroid 3 (single file, zero external deps)
#
#  LOGIC (the trap):
#   Retail trades breakouts. Smart money hunts their stops.
#   We do NOT trade the breakout — we trade the SWEEP + REJECT.
#
#   1. Opening Range (09:15-09:30): mark High/Low = liquidity pools
#   2. Pre-market filter: previous-day EOD delivery volume spike 200%+
#   3. Sweep: price breaks OR High/Low (retail FOMO enters)
#   4. Invalidation: next 1-2 min candle rejects BACK INSIDE the range
#   5. Confirm: OBI opposite-side dominance + Volume Delta >= 3x avg20
#   6. Entry: limit at the FVG / Order Block left by rejection candle
#   7. SL: 0.15% beyond the sweep wick | Target: opposite end of OR
#
#  HOW TO USE IN PYDROID 3:
#   1) Feed live data manually OR via CSV (both supported below)
#   2) CSV mode: 1-min OHLCV candles, columns:
#        timestamp,open,high,low,close,volume,ask_aggr,bid_aggr
#      (ask_aggr = aggressive buy volume at ask; bid_aggr = at bid)
#   3) Run:  python3 gts_gemini_pro_01.py --csv live.csv
#   4) Manual mode: use GeminiPro01.on_candle(...) from your feed code
# ============================================================

import argparse
import csv
import sys
from dataclasses import dataclass, field
from datetime import datetime, time as dtime
from typing import Optional, List

# ------------------------------------------------------------
# CONFIG — every threshold measurable (research defaults)
# ------------------------------------------------------------
GEMINI_CONFIG = {
    "strategy_id": "GTS-GEMINI-PRO-01",

    # --- session / opening range ---
    "or_start": dtime(9, 15),
    "or_end": dtime(9, 30),           # first 15 min = OR, NO trade
    "no_trade_before": dtime(9, 30),
    "entry_cutoff": dtime(14, 45),    # no fresh entry after this
    "flat_time": dtime(15, 15),       # mandatory square-off

    # --- pre-market stock filter (Jamuna's rule) ---
    "delivery_spike_min_pct": 200.0,  # prev-day EOD delivery volume spike
    "min_delivery_avg_base": 1000,    # base delivery vol must be meaningful

    # --- sweep & invalidation ---
    "sweep_break_min_pct": 0.02,      # OR boundary must break by >= X%
    "reject_back_inside_sec": 180,    # price back inside range within 3 min
    "reject_candle_max": 2,           # within 1-2 candles after break

    # --- order flow confirmation ---
    "obi_dominance_min": 0.40,        # |OBI| >= 0.40 toward trap direction
    "volume_delta_surge_x": 3.0,     # rejection candle vol >= 3x avg20
    "avg20_window": 20,

    # --- execution ---
    "sl_buffer_pct": 0.15,           # SL 0.15% beyond sweep wick
    "min_rr": 3.0,                   # target must offer >= 1:3
    "fvg_min_gap_pct": 0.05,         # FVG gap must be >= X% of price
    "risk_per_trade_pct": 1.0,
    "capital": 500000.0,

    # --- daily controls ---
    "max_trades_per_day": 3,
    "max_consecutive_losses": 2,
    "max_daily_loss_pct": 2.0,
}

NO_TRADE = {
    "OR_PENDING": "opening range not complete",
    "NO_SPIKE": "delivery spike filter failed",
    "NO_SWEEP": "no liquidity sweep yet",
    "NO_REJECT": "sweep but no rejection back inside",
    "OBI_FAIL": "order book imbalance not dominant",
    "VOL_FAIL": "volume delta surge < 3x avg20",
    "NO_FVG": "no FVG / order block left by rejection",
    "RR_INVALID": "risk-reward below minimum",
    "CUTOFF": "past entry cutoff",
    "DAILY_LIMIT": "max trades or daily loss reached",
    "CONSEC_LOSS": "consecutive-loss lock",
    "ALREADY_TRAPPED": "trap already taken on this OR side",
}


# ------------------------------------------------------------
# Data containers
# ------------------------------------------------------------
@dataclass
class Candle:
    ts: datetime
    o: float
    h: float
    l: float
    c: float
    volume: float
    ask_aggr: float = 0.0    # aggressive buy volume (at ask)
    bid_aggr: float = 0.0   # aggressive sell volume (at bid)

    def is_green(self):
        return self.c > self.o

    def body(self):
        return abs(self.c - self.o)

    def wick_up(self):
        return self.h - max(self.o, self.c)

    def wick_down(self):
        return min(self.o, self.c) - self.l


@dataclass
class TrapSignal:
    ts: datetime
    direction: str           # "SHORT" (bull trap) | "LONG" (bear trap)
    or_high: float
    or_low: float
    sweep_wick: float        # the extreme wick of the hunt candle
    entry: float             # FVG limit price
    stop: float
    target: float
    rr: float
    evidence: dict = field(default_factory=dict)
    reason: str = "GEMINI trap armed"


# ------------------------------------------------------------
# THE ENGINE
# ------------------------------------------------------------
class GeminiPro01:
    # State machine:
    # WAIT_OR -> OR_READY -> HUNT_ACTIVE -> TRAP_CONFIRMED -> TRADE_OPEN
    #          -> TRADE_CLOSED ; any time -> FLAT (session end)

    def __init__(self, config=None):
        self.cfg = config or dict(GEMINI_CONFIG)
        self.state = "WAIT_OR"
        self.or_high = 0.0
        self.or_low = 0.0
        self.or_done = False
        self.candles: List[Candle] = []
        self.signal: Optional[TrapSignal] = None
        self.position: Optional[dict] = None
        self.trades_today = 0
        self.consec_losses = 0
        self.day_pnl = 0.0
        self.log: list = []
        self.sweep_side = ""          # "UP" | "DOWN"
        self.sweep_wick = 0.0
        self.recent_breaks: list = []  # candle indexes after break

    # ---------------- logging ----------------
    def _log(self, ts, event, detail=""):
        self.log.append(f"{ts:%H:%M} [{event}] {detail}")

    # ---------------- opening range ----------------
    def _update_or(self, c: Candle):
        if not self.or_done:
            if self.cfg["or_start"] <= c.ts.time() < self.cfg["or_end"]:
                self.or_high = max(self.or_high, c.h)
                self.or_low = (min(self.or_low, c.l)
                               if self.or_low else c.l)
            elif c.ts.time() >= self.cfg["or_end"]:
                if self.or_high > 0 and self.or_low > 0:
                    self.or_done = True
                    self.state = "OR_READY"
                    self._log(c.ts, "OR_SET",
                              f"H={self.or_high:.2f} L={self.or_low:.2f}")
                else:
                    self.state = "NO_DATA_OR"
                    self._log(c.ts, "OR_FAIL", "no OR candles seen")

    # ---------------- pre-market filter (manual input) ----------------
    def set_delivery_filter(self, prev_delivery: float, avg_delivery: float):
        # Jamuna's rule: prev-day EOD delivery spike >= 200% over average
        if avg_delivery < self.cfg["min_delivery_avg_base"]:
            self.delivery_ok = False
            return False
        spike = (prev_delivery - avg_delivery) / avg_delivery * 100.0
        self.delivery_ok = spike >= self.cfg["delivery_spike_min_pct"]
        self._log(datetime.now(), "DELIVERY_FILTER",
                  f"spike={spike:.0f}% ok={self.delivery_ok}")
        return self.delivery_ok

    # ---------------- volume delta surge ----------------
    def _delta_surge_ok(self, c: Candle) -> tuple:
        n = self.cfg["avg20_window"]
        hist = [x.volume for x in self.candles[-n - 1:-1]]
        if len(hist) < n:
            return False, 0.0
        avg = sum(hist) / len(hist)
        surge = c.volume / avg if avg > 0 else 0.0
        return surge >= self.cfg["volume_delta_surge_x"], surge

    # ---------------- OBI (from aggressive volumes) ----------------
    def _obi(self, c: Candle) -> float:
        # OBI proxy from aggressive flow of the rejection window
        tot = c.ask_aggr + c.bid_aggr
        if tot <= 0:
            return 0.0
        return (c.ask_aggr - c.bid_aggr) / tot   # + = buy side dominant

    # ---------------- FVG detection on rejection candle ----------------
    def _find_fvg(self, rej: Candle, direction: str):
        # Fair Value Gap = 3-candle imbalance; on rejection we use the
        # gap left between the sweep candle body and next candle wick.
        i = self.candles.index(rej) if rej in self.candles else -1
        if i < 0 or i + 1 >= len(self.candles):
            return None
        nxt = self.candles[i + 1]
        price = rej.c
        if direction == "SHORT":
            # bull trap: look for a bearish FVG above current price
            gap_low = min(rej.o, nxt.h)
            gap_high = max(rej.c, rej.o)
            if gap_high - gap_low >= price * self.cfg["fvg_min_gap_pct"] / 100:
                return round((gap_low + gap_high) / 2, 2)
            return None
        # bear trap: bullish FVG below
        gap_high = max(rej.o, nxt.l)
        gap_low = min(rej.c, rej.o)
        if gap_high - gap_low >= price * self.cfg["fvg_min_gap_pct"] / 100:
            return round((gap_low + gap_high) / 2, 2)
        return None

    # ---------------- main candle handler ----------------
    def on_candle(self, c: Candle):
        """Feed every 1-min candle. Returns dict(action, ...)."""
        self._update_or(c)
        self.candles.append(c)

        # session flat — supreme
        if c.ts.time() >= self.cfg["flat_time"]:
            if self.position:
                return self._close_position(c, "SESSION_FLAT")
            return {"action": "NO_TRADE", "reason": "CUTOFF"}

        # manage open position first
        if self.position:
            return self._manage_position(c)

        # no trade before OR completes
        if not self.or_done:
            return {"action": "NO_TRADE", "reason": "OR_PENDING"}

        if not getattr(self, "delivery_ok", True):
            return {"action": "NO_TRADE", "reason": "NO_SPIKE"}

        if c.ts.time() >= self.cfg["entry_cutoff"]:
            return {"action": "NO_TRADE", "reason": "CUTOFF"}

        # daily controls
        if self.trades_today >= self.cfg["max_trades_per_day"]:
            return {"action": "NO_TRADE", "reason": "DAILY_LIMIT"}
        if self.consec_losses >= self.cfg["max_consecutive_losses"]:
            return {"action": "NO_TRADE", "reason": "CONSEC_LOSS"}
        if self.day_pnl <= -self.cfg["capital"] * self.cfg["max_daily_loss_pct"] / 100:
            return {"action": "NO_TRADE", "reason": "DAILY_LIMIT"}

        # ---------------- HUNT DETECTION ----------------
        br = self.cfg["sweep_break_min_pct"] / 100
        broke_up = c.h > self.or_high * (1 + br)
        broke_down = c.l < self.or_low * (1 - br)

        if self.state in ("OR_READY", "HUNT_ACTIVE") and not self.sweep_side:
            if broke_up:
                self.sweep_side = "UP"
                self.sweep_wick = c.h
                self.state = "HUNT_ACTIVE"
                self.recent_breaks = [len(self.candles) - 1]
                self._log(c.ts, "SWEEP_UP",
                          f"wick={c.h:.2f} (retail FOMO entering)")
            elif broke_down:
                self.sweep_side = "DOWN"
                self.sweep_wick = c.l
                self.state = "HUNT_ACTIVE"
                self.recent_breaks = [len(self.candles) - 1]
                self._log(c.ts, "SWEEP_DOWN", f"wick={c.l:.2f}")
            else:
                return {"action": "NO_TRADE", "reason": "NO_SWEEP"}

        # ---------------- INVALIDATION CHECK (back inside) ----------------
        if self.state == "HUNT_ACTIVE":
            idx = len(self.candles) - 1
            if idx not in self.recent_breaks:
                self.recent_breaks.append(idx)
            if len(self.recent_breaks) > self.cfg["reject_candle_max"] + 1:
                # too late — sweep accepted, not a trap
                self._log(c.ts, "SWEEP_ACCEPTED",
                          "price stayed outside — real breakout, reset")
                return self._reset_hunt()

            back_inside = (self.sweep_side == "UP" and c.c < self.or_high) or \
                          (self.sweep_side == "DOWN" and c.c > self.or_low)
            if not back_inside:
                return {"action": "NO_TRADE", "reason": "NO_REJECT"}

            # this candle is the REJECTION candle
            rej = c
            self.state = "TRAP_CONFIRMED"

            # ---------------- CONFIRMATIONS ----------------
            direction = "SHORT" if self.sweep_side == "UP" else "LONG"

            # OBI: bull trap needs SELLER dominance (negative OBI)
            obi = self._obi(rej)
            if direction == "SHORT" and obi > -self.cfg["obi_dominance_min"]:
                return self._reset_with("OBI_FAIL", obi)
            if direction == "LONG" and obi < self.cfg["obi_dominance_min"]:
                return self._reset_with("OBI_FAIL", obi)

            # Volume delta surge
            surge_ok, surge = self._delta_surge_ok(rej)
            if not surge_ok:
                return self._reset_with("VOL_FAIL", surge)

            # FVG entry
            fvg = self._find_fvg(rej, direction)
            if fvg is None:
                return self._reset_with("NO_FVG", 0)

            # ---------------- RISK / RR ----------------
            price = rej.c
            if direction == "SHORT":
                stop = self.sweep_wick * (1 + self.cfg["sl_buffer_pct"] / 100)
                target = self.or_low
                entry = fvg if fvg < price else price  # limit above
                risk = stop - entry
                reward = entry - target
            else:
                stop = self.sweep_wick * (1 - self.cfg["sl_buffer_pct"] / 100)
                target = self.or_high
                entry = fvg if fvg > price else price
                risk = entry - stop
                reward = target - entry
            if risk <= 0:
                return self._reset_with("RR_INVALID", 0)
            rr = reward / risk
            if rr < self.cfg["min_rr"]:
                return self._reset_with("RR_INVALID", rr)

            sig = TrapSignal(
                ts=rej.ts, direction=direction,
                or_high=self.or_high, or_low=self.or_low,
                sweep_wick=self.sweep_wick, entry=round(entry, 2),
                stop=round(stop, 2), target=round(target, 2),
                rr=round(rr, 2),
                evidence={"obi": round(obi, 2), "vol_surge": round(surge, 1),
                          "fvg": fvg, "candles_after_break":
                          len(self.recent_breaks)})
            self.signal = sig
            self._log(rej.ts, "TRAP_ARMED",
                      f"{direction} entry={entry:.2f} SL={stop:.2f} "
                      f"T={target:.2f} RR=1:{rr:.1f} OBI={obi:.2f} "
                      f"Vx={surge:.1f}")
            return {"action": "TRAP_SIGNAL", "signal": sig}

        return {"action": "NO_TRADE", "reason": "NO_SWEEP"}

    def _reset_with(self, reason, val):
        self._log(datetime.now(), "RESET", f"{reason} ({val})")
        out = self._reset_hunt()
        out["reason"] = reason
        return out

    def _reset_hunt(self):
        self.sweep_side = ""
        self.sweep_wick = 0.0
        self.recent_breaks = []
        self.state = "OR_READY" if self.or_done else "WAIT_OR"
        return {"action": "NO_TRADE", "reason": "NO_SWEEP"}

    # ---------------- trade lifecycle (signal -> entry -> manage) ------
    def take_entry(self, sig: TrapSignal, now: datetime, fill_price: float):
        # size: risk_per_trade% of capital / risk per share
        risk = abs(sig.stop - fill_price)
        if risk <= 0:
            return {"action": "NO_TRADE", "reason": "RR_INVALID"}
        budget = self.cfg["capital"] * self.cfg["risk_per_trade_pct"] / 100
        qty = int(budget // (risk * 1.0))       # simplify: 1 lot notion
        if qty < 1:
            qty = 1
        self.position = {"sig": sig, "entry": fill_price, "qty": qty,
                         "state": "TRADE_OPEN", "ts_in": now}
        self.trades_today += 1
        self._log(now, "ENTRY",
                  f"{sig.direction} @ {fill_price:.2f} qty={qty} "
                  f"SL={sig.stop:.2f} T={sig.target:.2f}")
        return {"action": "ENTERED", "qty": qty}

    def _manage_position(self, c: Candle):
        p = self.position
        sig = p["sig"]
        # note: for stock options use premium; here spot-level logic
        hit_sl = (sig.direction == "SHORT" and c.h >= sig.stop) or \
                 (sig.direction == "LONG" and c.l <= sig.stop)
        hit_t = (sig.direction == "SHORT" and c.l <= sig.target) or \
                (sig.direction == "LONG" and c.h >= sig.target)
        # both in same candle => assume SL first (conservative)
        if hit_sl:
            return self._close_position(c, "SL_HIT")
        if hit_t:
            return self._close_position(c, "TARGET_HIT")
        return {"action": "HOLD", "entry": p["entry"], "stop": sig.stop,
                "target": sig.target}

    def _close_position(self, c: Candle, reason: str):
        p = self.position
        sig = p["sig"]
        if reason == "SL_HIT":
            exit_px = sig.stop
        elif reason == "TARGET_HIT":
            exit_px = sig.target
        else:
            exit_px = c.c
        pnl = (p["entry"] - exit_px if sig.direction == "SHORT"
               else exit_px - p["entry"]) * p["qty"]
        self.day_pnl += pnl
        if pnl < 0:
            self.consec_losses += 1
        else:
            self.consec_losses = 0
        self._log(c.ts, "EXIT",
                  f"{reason} @ {exit_px:.2f} P&L={pnl:+.0f}")
        self.position = None
        self.sweep_side = ""
        self.state = "OR_READY" if self.or_done else "WAIT_OR"
        return {"action": "CLOSED", "reason": reason, "pnl": pnl,
                "day_pnl": self.day_pnl}

    # ---------------- report ----------------
    def report(self):
        lines = ["", "=" * 56,
                 "GTS-GEMINI-PRO-01 — LIQUIDITY TRAP REPORT",
                 "=" * 56,
                 f"trades today      : {self.trades_today}",
                 f"day P&L           : {self.day_pnl:+,.0f}",
                 f"consecutive losses: {self.consec_losses}",
                 "-" * 56]
        lines += self.log[-40:]
        return "\n".join(lines)


# ------------------------------------------------------------
# CSV loader (Pydroid-friendly)
# ------------------------------------------------------------
def load_csv(path):
    rows = []
    with open(path, newline="") as fh:
        for r in csv.DictReader(fh):
            rows.append(Candle(
                ts=datetime.strptime(r["timestamp"], "%Y-%m-%d %H:%M:%S"),
                o=float(r["open"]), h=float(r["high"]),
                l=float(r["low"]), c=float(r["close"]),
                volume=float(r["volume"]),
                ask_aggr=float(r.get("ask_aggr") or 0),
                bid_aggr=float(r.get("bid_aggr") or 0)))
    return rows


def main():
    ap = argparse.ArgumentParser(description="GTS-GEMINI-PRO-01 trap engine")
    ap.add_argument("--csv", help="1-min OHLCV csv file")
    ap.add_argument("--delivery", nargs=2, type=float,
                    metavar=("PREV", "AVG"),
                    help="prev-day delivery volume + its average base")
    args = ap.parse_args()

    eng = GeminiPro01()

    if args.delivery:
        eng.set_delivery_filter(args.delivery[0], args.delivery[1])

    if not args.csv:
        print(__doc__)
        print("no --csv given: engine idle. Feed candles via on_candle().")
        print(eng.report())
        return

    candles = load_csv(args.csv)
    print(f"replaying {len(candles)} candles ...")
    traps = 0
    for c in candles:
        out = eng.on_candle(c)
        if out.get("action") == "TRAP_SIGNAL":
            traps += 1
            sig = out["signal"]
            print(f"\n>>> TRAP SIGNAL #{traps} @ {sig.ts:%H:%M}")
            print(f"    {sig.direction} | sweep wick {sig.sweep_wick:.2f}")
            print(f"    entry(FVG) {sig.entry:.2f} | SL {sig.stop:.2f} "
                  f"| target {sig.target:.2f} | RR 1:{sig.rr:.1f}")
            print(f"    evidence: {sig.evidence}")
            # auto-execute in replay: assume limit fill at signal price
            eng.take_entry(sig, sig.ts, sig.entry)
    print(eng.report())
    print("\nnext: wire your live feed to eng.on_candle(), and set")
    print("eng.set_delivery_filter(prev, avg) each morning before 09:15.")


if __name__ == "__main__":
    main()
