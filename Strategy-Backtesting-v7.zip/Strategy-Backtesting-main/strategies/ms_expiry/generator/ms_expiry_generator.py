#!/usr/bin/env python3
# MS EXPY SPECIALIST v3.0 — Michel Quant Core (my full-power merge)
#
# Run:  python3 ms_expiry_generator.py
# Out:  ms_expiry/  + ms_expiry.zip
#
# Difference vs blueprint (user) version: MS core adds the 4-layer
# microstructure ENTRY STACK + regime pre-classification + wall engine.
# Single-authority architecture shared with the audited v2.1 rules.
#
# All generated code: # comments only (no docstrings). No .format() on code.

import os
import sys
import zipfile

OUT_DEFAULT = "ms_expiry"
ZIP_DEFAULT = "ms_expiry.zip"
VERSION = "3.0"
BRAND = "MS"

CONFIG = '''# ms_config.py — MS Expiry Specialist v''' + VERSION + '''
# Every threshold measurable. RESEARCH items must be frozen by backtest.

MS_CONFIG = {
    "brand": "''' + BRAND + '''",
    "version": "''' + VERSION + '''",

    # ---------------- universe ----------------
    "universe": {
        "allowed": ["NIFTY", "BANKNIFTY", "SENSEX"],
        "lot_size": {"NIFTY": 75, "BANKNIFTY": 35, "SENSEX": 20},
        "strike_step": {"NIFTY": 50, "BANKNIFTY": 100, "SENSEX": 100},
        "max_spread_pct_of_premium": 0.05,
        "min_chain_strikes": 21,
    },

    # ---------------- phases (supreme cutoff lives ONLY in ms_phases.py) ----
    "phases": {
        "market_open": "09:15",
        "p1": ("09:15", "10:30"),
        "p2": ("10:30", "12:30"),
        "gap": ("12:30", "14:40"),
        "p4_obs": ("14:40", "15:00"),
        "p4_entry_cutoff": "15:00",
        "final_square_off": "15:20",
    },

    # ---------------- regime pre-classification (binding) ----------------
    "regime": {
        "wall_symmetry_max_pct": 0.40,     # call/put max-OI spread vs spot
        "pin_maxpain_dist_pct": 0.30,     # spot within X% of max pain
        "gap_trend_pct": 0.70,            # overnight gap
        "maxpain_shift_pts": 100,         # 2-session shift => trend
        "iv_vs_avg_ratio": 1.00,          # ATM IV vs 4-expiry avg
        "mixed_reclassify_allowed": 1,
    },

    # ---------------- 4-layer entry stack (MS quant core) ----------------
    "stack": {
        # L1: delta-weighted OI
        "otm_call_oi_drop_pct": 8.0,          # per 5-min snapshot pair
        "deep_itm_put_oi_surge_pct": 5.0,
        "deep_itm_delta_min": 0.70,
        # L2: velocity
        "unwind_velocity_pct_5min": 5.0,      # below => rollover
        # L3: volume/OI
        "volume_oi_ratio_min": 1.50,          # below => noise
        # L4: tick gate
        "tick_window_sec": 180,
        "ask_bid_dominance_min": 1.40,        # bid-hit => FAKEOUT reject
        "cvd_agree_min": 0.0,                 # session CVD must not oppose
        # Vanna (post 13:15 only)
        "vanna_iv_drop_bps": 25,
        # wall mechanics
        "wall_approach_pct": 0.20,
        "wall_break_pct": 0.10,
        "wall_min_tests": 2,
    },

    # ---------------- confluence ----------------
    "confluence": {
        "min_independent_votes": 2,
        "min_vote_score": 0.35,
        "correlated_pairs": [["positioning", "greeks_energy"]],
        "direction_categories": ["structure", "flow", "positioning"],
    },

    # ---------------- persistence ----------------
    "persistence": {
        "min_confirm_seconds": 30,
        "regime_reversal_confirm_seconds": 45,
    },

    # ---------------- sizing (slippage explicit) ----------------
    "sizing": {
        "risk_per_trade_pct": 1.0,
        "slippage_buffer_pct": 0.10,
        "fees_per_order": 20.0,
        "taxes_pct": 0.05,
        "single_leg_shrink_only": True,
    },

    # ---------------- stops / exits ----------------
    "stops": {
        "absolute_cap_pct_of_premium": 50.0,   # RESEARCH
        "time_stop_minutes": {"P1": 45, "P2": 30, "P3": 90, "P4": 25},
        "trail_target1_book_pct": 0.50,
    },

    # ---------------- legs ----------------
    "legs": {
        "leg2_fill_timeout_sec": 20,
        "leg2_partial_fill_wait_sec": 10,
    },

    # ---------------- P4 ----------------
    "p4": {
        "hedge_fraction_of_primary": 0.25,
        "profit_expansion_trigger_r": 1.0,
        "hedge_pre_approval": True,
    },

    # ---------------- daily controls ----------------
    "daily": {
        "max_trades_per_day": 6,
        "max_consecutive_losses": 3,
        "max_open_positions": 2,
        "max_daily_loss_pct": 2.0,
    },

    # ---------------- DQ gate ----------------
    "dq": {
        "chain_max_age_sec": 180,
        "tick_max_age_sec": 5,
        "min_iv_surface_strikes": 15,
        "iv_surface_max_gap_steps": 2,
    },

    # ---------------- RESEARCH placeholders (Sec-19 style, enforceable) ----
    "research": {
        "event_blackout": {"events": [], "minutes_before": 30,
                            "minutes_after": 30},
        "latency_budget_ms": {"market_data": 500, "broker_ws": 800,
                                "end_to_end": 1500},
    },
}
'''

NO_TRADE = '''# ms_no_trade.py — machine-readable NO-TRADE codes (GTS standard)
DATA_STALE = "DATA_STALE"
CHAIN_BROKEN = "CHAIN_BROKEN"
DQ_GATE_FAILED = "DQ_GATE_FAILED"
LATENCY_HIGH = "LATENCY_HIGH"
SPREAD_WIDE = "SPREAD_WIDE"
LIQUIDITY_LOW = "LIQUIDITY_LOW"
UNIVERSE_INELIGIBLE = "UNIVERSE_INELIGIBLE"
MAPPING_INVALID = "MAPPING_INVALID"
EVENT_BLACKOUT = "EVENT_BLACKOUT"
NO_ACTIVE_PHASE = "NO_ACTIVE_PHASE"
GAP_NO_ENTRY = "GAP_NO_ENTRY"
REGIME_PINNING_BLOCKED = "REGIME_PINNING_BLOCKED"
REGIME_MIXED_LOCK = "REGIME_MIXED_LOCK"
PERSISTENCE_FAILED = "PERSISTENCE_FAILED"
NO_DIRECTION_VOTE = "NO_DIRECTION_VOTE"
CORRELATED_EVIDENCE_ONLY = "CORRELATED_EVIDENCE_ONLY"
L1_DELTA_OI_FAIL = "L1_DELTA_OI_FAIL"
L2_VELOCITY_FAIL = "L2_VELOCITY_FAIL"
L3_VOLUME_OI_FAIL = "L3_VOLUME_OI_FAIL"
L4_TICK_FAKEOUT = "L4_TICK_FAKEOUT"
L4_CVD_CONFLICT = "L4_CVD_CONFLICT"
VANNA_MISALIGNED = "VANNA_MISALIGNED"
WALL_NOT_ENGAGED = "WALL_NOT_ENGAGED"
ENERGY_VETO = "ENERGY_VETO"
IV_ANOMALY = "IV_ANOMALY"
BIDIRECTIONAL_BUILD = "BIDIRECTIONAL_BUILD"
FII_CONTRADICTION = "FII_CONTRADICTION"
BOTH_WALLS_BROKEN = "BOTH_WALLS_BROKEN"
PAYOFF_INVALID = "PAYOFF_INVALID"
RISK_LIMIT = "RISK_LIMIT"
DAILY_LOSS_LIMIT = "DAILY_LOSS_LIMIT"
CONSEC_LOSS_LOCK = "CONSEC_LOSS_LOCK"
MAX_TRADES = "MAX_TRADES"
MAX_OPEN_POSITIONS = "MAX_OPEN_POSITIONS"
STOP_UNDEFINED = "STOP_UNDEFINED"
RR_INVALID = "RR_INVALID"
MARGIN_SHORTFALL_SINGLE_LEG_SHRUNK = "MARGIN_SHORTFALL_SINGLE_LEG_SHRUNK"
MARGIN_SHORTFALL_MULTILEG_NO_TRADE = "MARGIN_SHORTFALL_MULTILEG_NO_TRADE"
APPROVAL_MISSING = "APPROVAL_MISSING"
APPROVAL_EXPIRED = "APPROVAL_EXPIRED"
P4_ENTRY_CUTOFF = "P4_ENTRY_CUTOFF"
LEG2_TIMEOUT = "LEG2_TIMEOUT"
CONFLICTING_POSITION = "CONFLICTING_POSITION"
KILL_SWITCH = "KILL_SWITCH"
BROKER_DISCONNECTED = "BROKER_DISCONNECTED"

ALL_CODES = {v for k, v in list(globals().items())
             if k.isupper() and isinstance(v, str) and k != "ALL_CODES"}
'''

AUDIT = '''# ms_audit.py — every signal + rejection recorded with code
class AuditLog:
    def __init__(self):
        self.rows = []

    def log(self, ts, mode, event, reason, payload=None):
        self.rows.append({"ts": ts, "mode": mode, "event": event,
                          "reason": reason, "payload": payload or {}})

    def tail(self, n=50):
        return self.rows[-n:]
'''

MARKET = '''# ms_market.py — chain features, walls, pin, DQ, GEX-energy, ticks
from datetime import datetime
from typing import Optional
import math

from ms_config import MS_CONFIG
import ms_no_trade as NT


class StrikeRow:
    def __init__(self, strike, ce_oi, pe_oi, ce_iv, pe_iv,
                 ce_ltp, pe_ltp, ce_vol, pe_vol):
        self.strike = strike
        self.ce_oi, self.pe_oi = ce_oi, pe_oi
        self.ce_iv, self.pe_iv = ce_iv, pe_iv
        self.ce_ltp, self.pe_ltp = ce_ltp, pe_ltp
        self.ce_vol, self.pe_vol = ce_vol, pe_vol


class ChainSnap:
    def __init__(self, ts, spot, rows):
        self.ts = ts
        self.spot = spot
        self.rows = {r.strike: r for r in rows}

    def walls(self):
        cw = max(self.rows.items(), key=lambda kv: kv[1].ce_oi, default=None)
        pw = max(self.rows.items(), key=lambda kv: kv[1].pe_oi, default=None)
        return (cw[0] if cw else None, pw[0] if pw else None)

    def max_pain(self):
        best, bp = None, None
        for s in sorted(self.rows):
            pain = sum((s - k) * r.ce_oi for k, r in self.rows.items() if s > k) \
                 + sum((k - s) * r.pe_oi for k, r in self.rows.items() if s < k)
            if bp is None or pain < bp:
                best, bp = s, pain
        return best

    def nearest_active_strike(self):
        c = [(abs(k - self.spot), k) for k, r in self.rows.items()
             if r.ce_oi + r.pe_oi > 0]
        return min(c)[1] if c else None

    def avg_atm_iv(self):
        ns = self.nearest_active_strike()
        if ns is None:
            return 0.0
        r = self.rows[ns]
        v = [x for x in (r.ce_iv, r.pe_iv) if x > 0]
        return sum(v) / len(v) if v else 0.0

    def otm_call_oi(self):
        return {k: r.ce_oi for k, r in self.rows.items() if k > self.spot}

    def deep_itm_puts(self, delta_min):
        # approx put delta via moneyness; deep ITM = |delta| >= delta_min
        out = {}
        for k, r in self.rows.items():
            if k >= self.spot:
                continue
            m = (k - self.spot) / (self.spot * 0.01)
            d = 1.0 / (1.0 + math.exp(1.6 * m))
            if d >= delta_min:
                out[k] = r.pe_oi
        return out


class MarketData:
    def __init__(self):
        self.chain = []
        self.ticks = []          # (ts, side 'A'/'B', qty, price)
        self.cvd = 0.0
        self.spot = 0.0
        self.spot_ts = None

    def on_chain(self, snap: ChainSnap):
        self.chain.append(snap)
        if len(self.chain) > 60:
            self.chain.pop(0)
        self.spot = snap.spot
        self.spot_ts = snap.ts

    def on_tick(self, ts, side, qty, price):
        self.ticks.append((ts, side.upper()[:1], qty, price))
        if len(self.ticks) > 50000:
            self.ticks.pop(0)
        self.cvd += qty if side.upper()[:1] == "A" else -qty

    def last(self, n=1):
        if not self.chain:
            return None
        return self.chain[-n]

    def two_snaps(self):
        # returns (prev, cur) or None
        if len(self.chain) < 2:
            return None
        return (self.chain[-2], self.chain[-1])

    def dq(self, now):
        c = MS_CONFIG["dq"]
        snap = self.last()
        out = {"ok": False, "chain_fresh": False, "iv_ok": False}
        if snap is None:
            return out
        out["chain_fresh"] = (now - snap.ts).total_seconds() <= c["chain_max_age_sec"]
        ivk = sorted(k for k, r in snap.rows.items()
                     if r.ce_iv > 0 and r.pe_iv > 0)
        out["iv_ok"] = len(ivk) >= c["min_iv_surface_strikes"]
        out["ok"] = out["chain_fresh"] and len(snap.rows) >= \
            MS_CONFIG["universe"]["min_chain_strikes"]
        return out

    def tick_dominance(self, now):
        w = MS_CONFIG["stack"]["tick_window_sec"]
        a = b = 0
        for ts, side, qty, _ in reversed(self.ticks):
            if (now - ts).total_seconds() > w:
                break
            if side == "A":
                a += qty
            else:
                b += qty
        return a, b

    def gex_energy(self):
        # magnitude only — NEVER direction. DOC-VERIFY convention.
        snap = self.last()
        if snap is None:
            return None
        t = 0.0
        for k, r in snap.rows.items():
            otm = max(k - snap.spot, 0) if r.ce_oi >= r.pe_oi else max(snap.spot - k, 0)
            t += (r.ce_oi - r.pe_oi) * otm
        return t

    def pin_ratio(self, minutes_left):
        # pin-distance normalized by IV expected move
        snap = self.last()
        if snap is None or minutes_left <= 0:
            return None
        ns = snap.nearest_active_strike()
        if ns is None:
            return None
        iv = snap.avg_atm_iv() / 100.0
        if iv <= 0:
            return None
        exp_move = snap.spot * iv * math.sqrt(max(minutes_left, 1) / (252 * 375))
        if exp_move <= 0:
            return None
        return abs(snap.spot - ns) / exp_move
'''

REGIME = '''# ms_regime.py — binding pre-classification: PINNING / TREND / MIXED
from ms_config import MS_CONFIG
import ms_no_trade as NT


class Regime:
    # classified once pre-market (+max 1 re-classify); drives mode blocking.
    def __init__(self):
        self.state = "UNCLASSIFIED"
        self.reclassify_used = 0

    def classify(self, md, gap_pct, fii_cash_net, fii_fut_adds_same_dir,
                 maxpain_shift_pts, iv_vs_avg):
        r = MS_CONFIG["regime"]
        snap = md.last()
        if snap is None:
            self.state = "UNCLASSIFIED"
            return
        cw, pw = snap.walls()
        mp = snap.max_pain()
        if cw is None or pw is None or mp is None:
            self.state = "MIXED"
            return
        sym = abs(cw - pw) / snap.spot * 100
        pin_dist = abs(snap.spot - mp) / snap.spot * 100
        pinning = (sym <= r["wall_symmetry_max_pct"]
                   and pin_dist <= r["pin_maxpain_dist_pct"]
                   and abs(gap_pct) < r["gap_trend_pct"] / 2
                   and iv_vs_avg <= r["iv_vs_avg_ratio"])
        trend = (abs(gap_pct) >= r["gap_trend_pct"]
                 and fii_fut_adds_same_dir
                 and abs(maxpain_shift_pts) >= r["maxpain_shift_pts"])
        if pinning:
            self.state = "PINNING"      # directional blocked; P3 spreads only
        elif trend:
            self.state = "TREND"        # directional playbook
        else:
            self.state = "MIXED"        # lock after 1 re-classify

    def reclassify(self, md, *args):
        if self.reclassify_used >= MS_CONFIG["regime"]["mixed_reclassify_allowed"]:
            self.state = "MIXED_LOCK"
            return False
        self.reclassify_used += 1
        self.classify(md, *args)
        return True

    def directional_allowed(self):
        return self.state == "TREND"
'''

WALLS = '''# ms_walls.py — wall engine: engagement, hold/break, tests
from ms_config import MS_CONFIG


class WallEngine:
    def __init__(self):
        self.tests = 0

    def engaged(self, snap):
        # spot within approach distance of call wall
        cw, _ = snap.walls()
        if cw is None:
            return False, None
        ap = MS_CONFIG["stack"]["wall_approach_pct"] / 100
        return snap.spot >= cw * (1 - ap), cw

    def broken(self, snap, cw):
        br = MS_CONFIG["stack"]["wall_break_pct"] / 100
        return snap.spot >= cw * (1 + br)

    def on_snap(self, snap):
        # count tests: spot approached wall then pulled back
        eng, cw = self.engaged(snap)
        if eng and cw is not None:
            br = MS_CONFIG["stack"]["wall_break_pct"] / 100
            if snap.spot < cw * (1 + br):
                self.tests += 1
        return self.tests >= MS_CONFIG["stack"]["wall_min_tests"]
'''

STACK = '''# ms_stack.py — THE 4-LAYER QUANT ENTRY STACK (MS core)
# OI is BIAS (3-5 min delayed). Ticks are ENTRY AUTHORITY.
from datetime import datetime

from ms_config import MS_CONFIG
import ms_no_trade as NT


class EntryStack:
    # Returns (passed, failing_code, evidence) for a LONG (call-wall unwind)
    # trade. Mirror logic for SHORT via mirror=True.
    def __init__(self):
        self.evidence = {}

    def evaluate(self, md, now, mirror=False):
        cfg = MS_CONFIG["stack"]
        pair = md.two_snaps()
        if pair is None:
            return False, NT.DATA_STALE, {}
        prev, cur = pair
        self.evidence = {}

        # ---- L1: delta-weighted OI ----
        if not mirror:
            otm_prev = {k: prev.rows[k].ce_oi for k in prev.otm_call_oi()}
            drops = {}
            for k, oi_prev in otm_prev.items():
                if k in cur.rows and oi_prev > 0:
                    d = (oi_prev - cur.rows[k].ce_oi) / oi_prev * 100
                    if d >= cfg["otm_call_oi_drop_pct"]:
                        drops[k] = d
            surges = {}
            prev_deep = prev.deep_itm_puts(cfg["deep_itm_delta_min"])
            cur_deep = cur.deep_itm_puts(cfg["deep_itm_delta_min"])
            for k, oi_p in prev_deep.items():
                if k in cur_deep and oi_p > 0:
                    s = (cur_deep[k] - oi_p) / oi_p * 100
                    if s >= cfg["deep_itm_put_oi_surge_pct"]:
                        surges[k] = s
            if not drops or not surges:
                return False, NT.L1_DELTA_OI_FAIL, {}
            self.evidence["l1_drops"] = drops
            self.evidence["l1_surges"] = surges
            top_unwind = max(drops, key=drops.get)
        else:
            # mirror: OTM PUT unwind + deep-ITM CALL surge
            otm_puts_prev = {k: prev.rows[k].pe_oi
                             for k, r in prev.rows.items() if k < prev.spot}
            drops = {}
            for k, oi_p in otm_puts_prev.items():
                if k in cur.rows and oi_p > 0:
                    d = (oi_p - cur.rows[k].pe_oi) / oi_p * 100
                    if d >= cfg["otm_call_oi_drop_pct"]:
                        drops[k] = d
            surges = {}
            prev_deep = {k: prev.rows[k].ce_oi for k, r in prev.rows.items()
                         if prev.spot - k >= prev.spot * 0.015}
            cur_deep = {k: cur.rows[k].ce_oi for k, r in cur.rows.items()
                        if cur.spot - k >= cur.spot * 0.015}
            for k, oi_p in prev_deep.items():
                if k in cur_deep and oi_p > 0:
                    s = (cur_deep[k] - oi_p) / oi_p * 100
                    if s >= cfg["deep_itm_put_oi_surge_pct"]:
                        surges[k] = s
            if not drops or not surges:
                return False, NT.L1_DELTA_OI_FAIL, {}
            self.evidence["l1_drops"] = drops
            self.evidence["l1_surges"] = surges
            top_unwind = max(drops, key=drops.get)

        # ---- L2: unwinding velocity at top strike ----
        side = "ce_oi" if not mirror else "pe_oi"
        oi_prev = getattr(prev.rows.get(top_unwind), side, 0)
        oi_cur = getattr(cur.rows.get(top_unwind), side, 0)
        if oi_prev <= 0:
            return False, NT.L2_VELOCITY_FAIL, {}
        vel = (oi_prev - oi_cur) / oi_prev * 100
        if vel < cfg["unwind_velocity_pct_5min"]:
            return False, NT.L2_VELOCITY_FAIL, {}
        self.evidence["velocity_pct"] = round(vel, 2)

        # ---- L3: volume/OI at the wall ----
        cw, pw = cur.walls()
        wall = (pw if mirror else cw)
        if wall is None or wall not in cur.rows:
            return False, NT.WALL_NOT_ENGAGED, {}
        row = cur.rows[wall]
        vol = row.pe_vol if mirror else row.ce_vol
        oi = row.pe_oi if mirror else row.ce_oi
        voi = vol / oi if oi > 0 else 0.0
        if voi < cfg["volume_oi_ratio_min"]:
            return False, NT.L3_VOLUME_OI_FAIL, {}
        self.evidence["v_oi"] = round(voi, 2)

        # ---- Vanna: post-13:15 IV alignment ----
        if now.hour * 60 + now.minute >= 13 * 60 + 15:
            iv_now = [r.ce_iv for r in cur.rows.values() if r.ce_iv > 0]
            iv_prev = [r.ce_iv for r in prev.rows.values() if r.ce_iv > 0]
            if iv_now and iv_prev:
                move_bps = (sum(iv_now)/len(iv_now) - sum(iv_prev)/len(iv_prev)) * 100
                aligned = move_bps <= -cfg["vanna_iv_drop_bps"]
                if not aligned:
                    return False, NT.VANNA_MISALIGNED, {}
            self.evidence["vanna_checked"] = True

        # ---- L4: tick gate (entry authority) ----
        a, b = md.tick_dominance(now)
        if b <= 0:
            ratio = 99.0 if a > 0 else 0.0
        else:
            ratio = a / b
        if mirror:
            # short side: seller dominance is bid-side aggressive
            ratio = (b / a) if a > 0 else (99.0 if b > 0 else 0.0)
        if ratio < 1.0:
            return False, NT.L4_TICK_FAKEOUT, {}   # bid-hit = fakeout
        if ratio < cfg["ask_bid_dominance_min"]:
            return False, NT.L4_CVD_CONFLICT, {}
        # session CVD must not oppose
        if not mirror and md.cvd < cfg["cvd_agree_min"]:
            return False, NT.L4_CVD_CONFLICT, {}
        if mirror and md.cvd > -cfg["cvd_agree_min"]:
            return False, NT.L4_CVD_CONFLICT, {}
        self.evidence["tick_ratio"] = round(ratio, 2)

        return True, None, self.evidence
'''

PHASES = '''# ms_phases.py — time-phase + SUPREME cutoff (only authority in codebase)
from datetime import time as dtime

from ms_config import MS_CONFIG


def _t(s):
    h, m = s.split(":")
    return dtime(int(h), int(m))


class Phases:
    def __init__(self):
        p = MS_CONFIG["phases"]
        self.p1 = (_t(p["p1"][0]), _t(p["p1"][1]))
        self.p2 = (_t(p["p2"][0]), _t(p["p2"][1]))
        self.gap = (_t(p["gap"][0]), _t(p["gap"][1]))
        self.p4 = (_t(p["p4_obs"][0]), _t(p["p4_obs"][1]))
        self.p4_cutoff = _t(p["p4_entry_cutoff"])
        self.square_off = _t(p["final_square_off"])
        self.open = _t(p["market_open"])

    def modes_for(self, t):
        if t < self.open:
            return "PRE", []
        if self.p1[0] <= t < self.p1[1]:
            return "EARLY", ["P1"]
        if self.p2[0] <= t < self.p2[1]:
            return "MID", ["P2"]
        if self.gap[0] <= t < self.gap[1]:
            return "GAP", []          # explicit: no mode, monitoring only
        if self.p4[0] <= t < self.p4[1]:
            return "LATE_OBS", ["P4"]
        return "LATE_MGMT", []

    def p4_entry_ok(self, t):
        return self.p4[0] <= t < self.p4_cutoff

    def past_square_off(self, t):
        return t >= self.square_off
'''

GATES = '''# ms_gates.py — ordered hard gates + daily controls (cutoff NOT here)
from datetime import datetime

from ms_config import MS_CONFIG
import ms_no_trade as NT


class Gates:
    def __init__(self):
        self.kill = False
        self.broker = True
        self.mapping_valid = True

    def check(self, state, md, now, instrument):
        # ordered; first failure stops evaluation
        if self.kill:
            return NT.KILL_SWITCH
        if not self.broker:
            return NT.BROKER_DISCONNECTED
        cal = MS_CONFIG["research"]["event_blackout"]
        for ev in cal["events"]:
            if ev.get("start", datetime.min) <= now <= ev.get("end", datetime.max):
                return NT.EVENT_BLACKOUT
        snap = md.last()
        if snap is None or not snap.rows:
            return NT.CHAIN_BROKEN
        dq = md.dq(now)
        if not dq["chain_fresh"]:
            return NT.DATA_STALE
        if (state.latency_ms or 0) > MS_CONFIG["research"]["latency_budget_ms"]["end_to_end"]:
            return NT.LATENCY_HIGH
        base = instrument.split(":")[0]
        if base not in MS_CONFIG["universe"]["allowed"]:
            return NT.UNIVERSE_INELIGIBLE
        if self.mapping_valid is False:
            return NT.MAPPING_INVALID
        d = MS_CONFIG["daily"]
        if state.day_pnl <= -state.capital * d["max_daily_loss_pct"] / 100:
            return NT.DAILY_LOSS_LIMIT
        if state.consec_losses >= d["max_consecutive_losses"]:
            return NT.CONSEC_LOSS_LOCK
        if state.trades_today >= d["max_trades_per_day"]:
            return NT.MAX_TRADES
        if len(state.open_pos) >= d["max_open_positions"]:
            return NT.MAX_OPEN_POSITIONS
        if any(p["instrument"] == instrument for p in state.open_pos):
            return NT.CONFLICTING_POSITION
        return None
'''

CONFLUENCE = '''# ms_confluence.py — direction vote; greeks_energy banned; correlated=1
from ms_config import MS_CONFIG


class Vote:
    def __init__(self):
        self.scores = {}

    def add(self, category, score):
        if category in MS_CONFIG["confluence"]["direction_categories"] \
                and -1 <= score <= 1:
            self.scores[category] = score

    def result(self):
        cfg = MS_CONFIG["confluence"]
        cands = {c: (1 if s > 0 else -1)
                 for c, s in self.scores.items()
                 if abs(s) >= cfg["min_vote_score"]}
        for a, b in cfg["correlated_pairs"]:
            if a in cands and b in cands:
                cands.pop(b, None)
        pos = [c for c, v in cands.items() if v > 0]
        neg = [c for c, v in cands.items() if v < 0]
        if len(pos) >= cfg["min_independent_votes"]:
            return +1, pos
        if len(neg) >= cfg["min_independent_votes"]:
            return -1, neg
        return 0, []
'''

SIZING = '''# ms_sizing.py — Actual Risk = Lots x Multiplier x PremiumMove + Slip + Fees
from ms_config import MS_CONFIG
import ms_no_trade as NT


def compute_size(budget, premium_move, multiplier, slippage_pct, fees):
    unit = multiplier * premium_move
    per_lot = unit * (1 + slippage_pct) + fees
    if per_lot <= 0:
        return None, NT.STOP_UNDEFINED
    lots = int(budget // per_lot)          # floor only, never round up
    if lots < 1:
        return None, NT.RR_INVALID
    return {"lots": lots, "per_lot": per_lot,
            "actual_risk": lots * per_lot}, None


def margin_gate(single_leg, lots, margin_avail, margin_per_lot):
    if lots * margin_per_lot <= margin_avail:
        return lots, None
    shrunk = int(margin_avail // margin_per_lot) if margin_per_lot > 0 else 0
    if single_leg and shrunk >= 1:
        return shrunk, NT.MARGIN_SHORTFALL_SINGLE_LEG_SHRUNK
    if single_leg:
        return 0, NT.RISK_LIMIT
    return None, NT.MARGIN_SHORTFALL_MULTILEG_NO_TRADE
'''

APPROVAL = '''# ms_approval.py — YES gate + P4 hedge pre-approval (no bypass, any mode)
from ms_config import MS_CONFIG
import ms_no_trade as NT


class Package:
    def __init__(self, mode, instrument, direction, entry, stop, target,
                 hold_minutes, risk_amt, lots, evidence, ts, hedge=None):
        self.mode, self.instrument, self.direction = mode, instrument, direction
        self.entry, self.stop, self.target = entry, stop, target
        self.hold_minutes, self.risk_amt, self.lots = hold_minutes, risk_amt, lots
        self.evidence, self.ts = evidence, ts
        self.hedge = hedge       # pre-specified contingent hedge spec
        self.approved = False
        self.expired = False
        self.ts_ok = None

    def approve(self, ts):
        self.approved, self.ts_ok = True, ts

    def valid(self, now, price, risk_now):
        if self.expired or not self.approved:
            return False
        if abs(price - self.entry) / max(self.entry, 1e-9) > 0.005:
            self.expired = True
            return False
        if abs(risk_now - self.risk_amt) / max(self.risk_amt, 1e-9) > 0.20:
            self.expired = True
            return False
        if (now - self.ts_ok).total_seconds() > self.hold_minutes * 60:
            self.expired = True
            return False
        return True

    def hedge_pre_approved(self, spec):
        if not MS_CONFIG["p4"]["hedge_pre_approval"] or not self.hedge:
            return False
        c = self.hedge
        return (abs(spec["fraction"] - c["fraction"]) <= 0.02
                and spec["trigger_r"] >= c["trigger_r"])
'''

LEGS = '''# ms_legs.py — leg-risk state machine with LEG_2_PARTIAL
from datetime import datetime, timedelta

from ms_config import MS_CONFIG
import ms_no_trade as NT


class LegMachine:
    def __init__(self, now, is_spread):
        self.state = "ENTRY_PENDING"
        self.is_spread = is_spread
        self.deadline = now + timedelta(
            seconds=MS_CONFIG["legs"]["leg2_fill_timeout_sec"])
        self.leg2_expected = 0
        self.leg2_filled = 0
        self.partial_deadline = None

    def leg1_filled(self, now):
        self.state = "LEG_2_PENDING"
        self.deadline = now + timedelta(
            seconds=MS_CONFIG["legs"]["leg2_fill_timeout_sec"])

    def leg2(self, lots, now):
        if lots >= self.leg2_expected:
            self.state = "HEDGE_ACTIVE"
            self.leg2_filled = lots
            return
        self.state = "LEG_2_PARTIAL"
        self.leg2_filled = lots
        if self.partial_deadline is None:
            self.partial_deadline = now + timedelta(
                seconds=MS_CONFIG["legs"]["leg2_partial_fill_wait_sec"])

    def tick(self, now):
        if self.state == "LEG_2_PENDING" and now >= self.deadline:
            self.state = "EMERGENCY_EXIT"
            return "EMERGENCY_CLOSE_LEG1", NT.LEG2_TIMEOUT
        if self.state == "LEG_2_PARTIAL":
            if self.leg2_filled >= self.leg2_expected:
                self.state = "HEDGE_ACTIVE"
            elif now >= self.partial_deadline:
                self.state = "EMERGENCY_EXIT"
                return "EMERGENCY_CLOSE_LEG1", NT.LEG2_TIMEOUT
        if self.state == "EMERGENCY_EXIT":
            return "EMERGENCY_CLOSE_LEG1", NT.LEG2_TIMEOUT
        return "", None
'''

ENGINE = '''# ms_engine.py — orchestration: gates -> phase -> regime -> stack -> approve
from datetime import datetime

from ms_config import MS_CONFIG
import ms_no_trade as NT
from ms_market import MarketData
from ms_phases import Phases
from ms_gates import Gates
from ms_regime import Regime
from ms_walls import WallEngine
from ms_stack import EntryStack
from ms_confluence import Vote
from ms_sizing import compute_size, margin_gate
from ms_approval import Package
from ms_legs import LegMachine
from ms_audit import AuditLog


class State:
    def __init__(self, capital):
        self.capital = capital
        self.day_pnl = 0.0
        self.trades_today = 0
        self.consec_losses = 0
        self.open_pos = []
        self.latency_ms = 0


class MSEngine:
    def __init__(self, capital=500000.0):
        self.md = MarketData()
        self.ph = Phases()
        self.gates = Gates()
        self.regime = Regime()
        self.walls = WallEngine()
        self.stack = EntryStack()
        self.state = State(capital)
        self.audit = AuditLog()
        self.persist = {}

    # ---------- persistence (hysteresis) ----------
    def _persist(self, key, cond, now):
        if not cond:
            self.persist.pop(key, None)
            return False
        need = MS_CONFIG["persistence"]["min_confirm_seconds"]
        rec = self.persist.get(key)
        if rec is None:
            self.persist[key] = now
            return False
        return (now - rec).total_seconds() >= need

    # ---------- main tick ----------
    def on_eval(self, now, instrument, minutes_left, vote_inputs=None):
        # 0) SUPREME cutoff — only ms_phases owns it
        if self.ph.past_square_off(now.time()):
            return {"action": "SQUARE_OFF_ALL", "reason": "FINAL_SQUARE_OFF"}

        # 1) ordered hard gates
        code = self.gates.check(self.state, self.md, now, instrument)
        if code:
            self.audit.log(now, "-", "NO_TRADE", code)
            return {"action": "NO_TRADE", "reason": code}

        # 2) phase
        phase, modes = self.ph.modes_for(now.time())
        if not modes:
            self.audit.log(now, "-", "NO_TRADE", NT.NO_ACTIVE_PHASE,
                           {"phase": phase})
            return {"action": "NO_TRADE", "reason": NT.NO_ACTIVE_PHASE,
                    "phase": phase}

        # 3) regime blocking
        if self.regime.state == "PINNING" and any(m in modes for m in ("P1", "P2", "P4")):
            self.audit.log(now, modes[0], "NO_TRADE", NT.REGIME_PINNING_BLOCKED)
            return {"action": "NO_TRADE", "reason": NT.REGIME_PINNING_BLOCKED}
        if self.regime.state == "MIXED_LOCK":
            self.audit.log(now, "-", "NO_TRADE", NT.REGIME_MIXED_LOCK)
            return {"action": "NO_TRADE", "reason": NT.REGIME_MIXED_LOCK}

        # 4) direction vote (engine feeds normalized evidence)
        v = Vote()
        if vote_inputs:
            for cat, sc in vote_inputs.items():
                v.add(cat, sc)
        direction, cats = v.result()
        if direction == 0:
            self.audit.log(now, modes[0], "NO_TRADE", NT.NO_DIRECTION_VOTE)
            return {"action": "NO_TRADE", "reason": NT.NO_DIRECTION_VOTE}

        # 5) wall engagement (P1/P2/P4 directional need a wall story)
        snap = self.md.last()
        engaged = self.walls.on_snap(snap) if snap else False
        if not engaged:
            self.audit.log(now, modes[0], "NO_TRADE", NT.WALL_NOT_ENGAGED)
            return {"action": "NO_TRADE", "reason": NT.WALL_NOT_ENGAGED}

        # 6) THE 4-LAYER STACK (mirror = direction < 0)
        ok, fail, ev = self.stack.evaluate(self.md, now, mirror=(direction < 0))
        if not ok:
            self.audit.log(now, modes[0], "NO_TRADE", fail, ev)
            return {"action": "NO_TRADE", "reason": fail}

        # 7) persistence confirm
        if not self._persist(modes[0] + str(direction), True, now):
            self.audit.log(now, modes[0], "NO_TRADE", NT.PERSISTENCE_FAILED)
            return {"action": "NO_TRADE", "reason": NT.PERSISTENCE_FAILED}

        # 8) sizing + package
        budget = self.state.capital * MS_CONFIG["sizing"]["risk_per_trade_pct"] / 100
        prem_move = max(snap.spot * 0.004, 1.0)   # DOC-VERIFY live pricing
        size, err = compute_size(budget, prem_move,
                                 multiplier=MS_CONFIG["universe"]["lot_size"][
                                     instrument.split(":")[0]],
                                 slippage_pct=MS_CONFIG["sizing"]["slippage_buffer_pct"],
                                 fees=MS_CONFIG["sizing"]["fees_per_order"])
        if err:
            self.audit.log(now, modes[0], "NO_TRADE", err)
            return {"action": "NO_TRADE", "reason": err}
        mode = modes[0]
        pkg = Package(mode, instrument, direction,
                      entry=snap.spot, stop=snap.spot - 1,
                      target=snap.spot + prem_move,
                      hold_minutes=MS_CONFIG["stops"]["time_stop_minutes"][mode],
                      risk_amt=size["actual_risk"], lots=size["lots"],
                      evidence={"stack": ev, "votes": cats}, ts=now,
                      hedge={"fraction": MS_CONFIG["p4"]["hedge_fraction_of_primary"],
                             "trigger_r": MS_CONFIG["p4"]["profit_expansion_trigger_r"]}
                      if mode == "P4" else None)
        self.audit.log(now, mode, "SIGNAL", "package_ready",
                       {"lots": size["lots"], "stack": ev})
        return {"action": "APPROVAL_REQUIRED", "package": pkg, "mode": mode}

    def on_approval(self, pkg, now, yes):
        if not yes:
            self.audit.log(now, pkg.mode, "NO_TRADE", NT.APPROVAL_MISSING)
            return {"action": "NO_TRADE", "reason": NT.APPROVAL_MISSING}
        if pkg.expired:
            self.audit.log(now, pkg.mode, "NO_TRADE", NT.APPROVAL_EXPIRED)
            return {"action": "NO_TRADE", "reason": NT.APPROVAL_EXPIRED}
        pkg.approve(now)
        self.state.trades_today += 1
        self.state.open_pos.append({"instrument": pkg.instrument,
                                    "mode": pkg.mode, "pkg": pkg})
        self.audit.log(now, pkg.mode, "ENTRY", "approved",
                       {"lots": pkg.lots})
        return {"action": "ENTERED", "legs": LegMachine(now, pkg.mode == "P3")}

    def request_hedge(self, pkg, spec, now):
        if pkg.hedge_pre_approved(spec):
            self.audit.log(now, "P4", "ENTRY", "hedge_pre_approved")
            return {"action": "HEDGE_OK"}
        return {"action": "HEDGE_NEEDS_APPROVAL",
                "reason": NT.APPROVAL_MISSING}
'''

TESTS = '''# tests/test_ms.py — run: python3 -m pytest tests/ -q
from datetime import datetime, time as dtime

from ms_engine import MSEngine
from ms_phases import Phases
from ms_confluence import Vote
from ms_regime import Regime
from ms_stack import EntryStack
from ms_config import MS_CONFIG
import ms_no_trade as NT


def test_cutoff_supreme():
    ph = Phases()
    assert ph.past_square_off(dtime(15, 21)) is True
    assert ph.modes_for(dtime(13, 0)) == ("GAP", [])   # explicit no-mode gap
    assert ph.p4_entry_ok(dtime(14, 59)) is True
    assert ph.p4_entry_ok(dtime(15, 1)) is False


def test_greeks_energy_never_votes():
    v = Vote()
    v.add("greeks_energy", 1.0)
    v.add("structure", 0.9)
    v.add("positioning", 0.9)
    assert v.result()[0] == +1        # greeks_energy ignored, 2 real votes
    v2 = Vote()
    v2.add("greeks_energy", 1.0)
    v2.add("structure", 0.9)
    assert v2.result()[0] == 0        # 1 real vote never enough


def test_no_trade_without_data():
    eng = MSEngine()
    now = datetime(2026, 9, 24, 9, 45)
    out = eng.on_eval(now, "NIFTY:W", 60, {"structure": 0.8, "flow": 0.7})
    assert out["action"] == "NO_TRADE"
    assert out["reason"] in NT.ALL_CODES


def test_pinning_blocks_directional():
    rg = Regime()
    rg.state = "PINNING"
    assert rg.directional_allowed() is False


def test_stack_layer_codes_exist():
    # the 4 layers have dedicated machine codes
    for code in (NT.L1_DELTA_OI_FAIL, NT.L2_VELOCITY_FAIL,
                 NT.L3_VOLUME_OI_FAIL, NT.L4_TICK_FAKEOUT,
                 NT.VANNA_MISALIGNED):
        assert code in NT.ALL_CODES


def test_correlated_pair_config():
    assert ["positioning", "greeks_energy"] in MS_CONFIG["confluence"]["correlated_pairs"]
'''

README = '''# MS Expiry Specialist v''' + VERSION + ''' — Michel Quant Core

**MS = आपका quant edge, हमेशा के लिए।** Blueprint (user) version से अंतर:
यह core **4-layer microstructure entry stack** + **regime pre-classification**
+ **wall engine** जोड़ता है — बाकी single-authority architecture shared है।

## Entry Stack (हर directional entry पर, ordered)
L1 Δ-OI (OTM unwind + deep-ITM confirm) → L2 velocity (5%/5min) →
L3 V/OI (>1.5) → Vanna (post-13:15) → L4 tick gate (bid-hit = FAKEOUT)

## Files
ms_config / ms_no_trade / ms_audit / ms_market (chain, ticks, GEX-energy) /
ms_regime (PINNING/TREND/MIXED) / ms_walls / ms_stack / ms_phases (supreme
cutoff) / ms_gates (ordered) / ms_confluence / ms_sizing / ms_approval /
ms_legs / ms_engine / tests

## Run
python3 -m pytest tests/ -q

## DOC-VERIFY (never silently assumed)
1. GEX convention (Definitions Appendix)
2. Live bid/ask spread gate
3. Premium-movement sizing input
4. All RESEARCH thresholds — sweep-freeze on 40-50 expiries, bucket-wise
'''

FILES = {
    "ms_config.py": CONFIG,
    "ms_no_trade.py": NO_TRADE,
    "ms_audit.py": AUDIT,
    "ms_market.py": MARKET,
    "ms_regime.py": REGIME,
    "ms_walls.py": WALLS,
    "ms_stack.py": STACK,
    "ms_phases.py": PHASES,
    "ms_gates.py": GATES,
    "ms_confluence.py": CONFLUENCE,
    "ms_sizing.py": SIZING,
    "ms_approval.py": APPROVAL,
    "ms_legs.py": LEGS,
    "ms_engine.py": ENGINE,
    "tests/__init__.py": "",
    "tests/test_ms.py": TESTS,
    "README.md": README,
}


def self_check():
    problems = []
    # 1) generated bodies must not contain triple-quotes (we use ' templates)
    for path, body in FILES.items():
        if "'''" in body:
            problems.append("triple-quote inside generated body: " + path)
    # 2) single authority: cutoff only in ms_phases
    for other in ("ms_gates.py", "ms_engine.py", "ms_market.py", "ms_stack.py"):
        if "square_off_time" in FILES.get(other, "") or \
                "final_square_off" in FILES.get(other, ""):
            problems.append("cutoff leaked outside ms_phases: " + other)
    # 3) greeks_energy banned from direction categories
    if "greeks_energy" in MS_CONFIG_STUB.direction_categories:
        problems.append("greeks_energy in direction categories")
    # 4) all NO_TRADE emissions use codes module
    for path in ("ms_engine.py", "ms_gates.py", "ms_stack.py"):
        if "NO_TRADE" in FILES[path] and "ms_no_trade" not in FILES[path]:
            problems.append("NO_TRADE without codes import: " + path)
    # 5) 4-layer codes present
    src = FILES["ms_no_trade.py"]
    for code in ("L1_DELTA_OI_FAIL", "L2_VELOCITY_FAIL",
                 "L3_VOLUME_OI_FAIL", "L4_TICK_FAKEOUT", "VANNA_MISALIGNED"):
        if code not in src:
            problems.append("missing stack code: " + code)
    # 6) hedge pre-approval (audit A4) present
    if "hedge_pre_approved" not in FILES["ms_approval.py"]:
        problems.append("hedge pre-approval missing")
    return problems


class MS_CONFIG_STUB:
    # extracted from CONFIG template for self_check (no exec of templates)
    direction_categories = ["structure", "flow", "positioning"]


def main():
    problems = self_check()
    if problems:
        print("SELF-CHECK FAILED:")
        for p in problems:
            print("  -", p)
        sys.exit(1)

    out = sys.argv[1] if len(sys.argv) > 1 else OUT_DEFAULT
    zipf = sys.argv[2] if len(sys.argv) > 2 else ZIP_DEFAULT

    for rel, body in sorted(FILES.items()):
        p = os.path.join(out, rel)
        d = os.path.dirname(p)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(body)

    with zipfile.ZipFile(zipf, "w", zipfile.ZIP_DEFLATED) as z:
        for root, _, fs in os.walk(out):
            for fn in sorted(fs):
                full = os.path.join(root, fn)
                z.write(full, full)

    print("SELF-CHECK PASSED — MS Expiry Specialist v%s — %d files."
          % (VERSION, len(FILES)))
    print("tree: %s | zip: %s" % (out, zipf))
    print("next: cd %s && python3 -m pytest tests/ -q" % out)


if __name__ == "__main__":
    main()
