"""MS Expiry Specialist v3.0 registry wrapper.

Engine ka core: core/ms_*.py (generator: generator/ms_expiry_generator.py se bana, self-check paas).
Ye option chain snapshots (strikes, OI, IV) aur ticks par chalta hai, OHLCV candles par nahi.
Hub me option_chain ka data abhi nahi bhara gaya, isliye engine ise BLOCKED dikhata hai.
Adapter abhi chain snapshots ko core engine se nahi jodta; ye kaam data aane ke baad hoga.
"""
from strategies.base import Strategy
from strategies._bridge import not_wired


class MsExpiryAdapter(Strategy):
    strategy_id = "ms_expiry"
    required_data = ("option_chain",)

    def on_bar(self, ctx):
        return not_wired(self.strategy_id, self.required_data)
