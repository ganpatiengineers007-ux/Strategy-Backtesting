# ms_confluence.py — direction vote; greeks_energy banned; correlated=1
from ms_config import MS_CONFIG


class Vote:
    def __init__(self):
        self.scores = {}

    def add(self, category, score):
        if category in MS_CONFIG["confluence"]["direction_categories"]                 and -1 <= score <= 1:
            self.scores[category] = score

    def result(self):
        cfg = MS_CONFIG["confluence"]
        cands = {c: (1 if s > 0 else -1)
                 for c, s in self.scores.items()
                 if abs(s) >= cfg["min_vote_score"]}
        for a, b in cfg["correlated_pairs"]:
            if a in cands and b in cands:
                cands.pop(b, None)
        pos = [c for c, v in cands.items() if v > 0]
        neg = [c for c, v in cands.items() if v < 0]
        if len(pos) >= cfg["min_independent_votes"]:
            return +1, pos
        if len(neg) >= cfg["min_independent_votes"]:
            return -1, neg
        return 0, []
