# ms_gates.py — ordered hard gates + daily controls (cutoff NOT here)
from datetime import datetime

from ms_config import MS_CONFIG
import ms_no_trade as NT


class Gates:
    def __init__(self):
        self.kill = False
        self.broker = True
        self.mapping_valid = True

    def check(self, state, md, now, instrument):
        # ordered; first failure stops evaluation
        if self.kill:
            return NT.KILL_SWITCH
        if not self.broker:
            return NT.BROKER_DISCONNECTED
        cal = MS_CONFIG["research"]["event_blackout"]
        for ev in cal["events"]:
            if ev.get("start", datetime.min) <= now <= ev.get("end", datetime.max):
                return NT.EVENT_BLACKOUT
        snap = md.last()
        if snap is None or not snap.rows:
            return NT.CHAIN_BROKEN
        dq = md.dq(now)
        if not dq["chain_fresh"]:
            return NT.DATA_STALE
        if (state.latency_ms or 0) > MS_CONFIG["research"]["latency_budget_ms"]["end_to_end"]:
            return NT.LATENCY_HIGH
        base = instrument.split(":")[0]
        if base not in MS_CONFIG["universe"]["allowed"]:
            return NT.UNIVERSE_INELIGIBLE
        if self.mapping_valid is False:
            return NT.MAPPING_INVALID
        d = MS_CONFIG["daily"]
        if state.day_pnl <= -state.capital * d["max_daily_loss_pct"] / 100:
            return NT.DAILY_LOSS_LIMIT
        if state.consec_losses >= d["max_consecutive_losses"]:
            return NT.CONSEC_LOSS_LOCK
        if state.trades_today >= d["max_trades_per_day"]:
            return NT.MAX_TRADES
        if len(state.open_pos) >= d["max_open_positions"]:
            return NT.MAX_OPEN_POSITIONS
        if any(p["instrument"] == instrument for p in state.open_pos):
            return NT.CONFLICTING_POSITION
        return None
