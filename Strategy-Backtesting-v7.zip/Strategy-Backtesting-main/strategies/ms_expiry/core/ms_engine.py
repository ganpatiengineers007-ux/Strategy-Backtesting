# ms_engine.py — orchestration: gates -> phase -> regime -> stack -> approve
from datetime import datetime

from ms_config import MS_CONFIG
import ms_no_trade as NT
from ms_market import MarketData
from ms_phases import Phases
from ms_gates import Gates
from ms_regime import Regime
from ms_walls import WallEngine
from ms_stack import EntryStack
from ms_confluence import Vote
from ms_sizing import compute_size, margin_gate
from ms_approval import Package
from ms_legs import LegMachine
from ms_audit import AuditLog


class State:
    def __init__(self, capital):
        self.capital = capital
        self.day_pnl = 0.0
        self.trades_today = 0
        self.consec_losses = 0
        self.open_pos = []
        self.latency_ms = 0


class MSEngine:
    def __init__(self, capital=500000.0):
        self.md = MarketData()
        self.ph = Phases()
        self.gates = Gates()
        self.regime = Regime()
        self.walls = WallEngine()
        self.stack = EntryStack()
        self.state = State(capital)
        self.audit = AuditLog()
        self.persist = {}

    # ---------- persistence (hysteresis) ----------
    def _persist(self, key, cond, now):
        if not cond:
            self.persist.pop(key, None)
            return False
        need = MS_CONFIG["persistence"]["min_confirm_seconds"]
        rec = self.persist.get(key)
        if rec is None:
            self.persist[key] = now
            return False
        return (now - rec).total_seconds() >= need

    # ---------- main tick ----------
    def on_eval(self, now, instrument, minutes_left, vote_inputs=None):
        # 0) SUPREME cutoff — only ms_phases owns it
        if self.ph.past_square_off(now.time()):
            return {"action": "SQUARE_OFF_ALL", "reason": "FINAL_SQUARE_OFF"}

        # 1) ordered hard gates
        code = self.gates.check(self.state, self.md, now, instrument)
        if code:
            self.audit.log(now, "-", "NO_TRADE", code)
            return {"action": "NO_TRADE", "reason": code}

        # 2) phase
        phase, modes = self.ph.modes_for(now.time())
        if not modes:
            self.audit.log(now, "-", "NO_TRADE", NT.NO_ACTIVE_PHASE,
                           {"phase": phase})
            return {"action": "NO_TRADE", "reason": NT.NO_ACTIVE_PHASE,
                    "phase": phase}

        # 3) regime blocking
        if self.regime.state == "PINNING" and any(m in modes for m in ("P1", "P2", "P4")):
            self.audit.log(now, modes[0], "NO_TRADE", NT.REGIME_PINNING_BLOCKED)
            return {"action": "NO_TRADE", "reason": NT.REGIME_PINNING_BLOCKED}
        if self.regime.state == "MIXED_LOCK":
            self.audit.log(now, "-", "NO_TRADE", NT.REGIME_MIXED_LOCK)
            return {"action": "NO_TRADE", "reason": NT.REGIME_MIXED_LOCK}

        # 4) direction vote (engine feeds normalized evidence)
        v = Vote()
        if vote_inputs:
            for cat, sc in vote_inputs.items():
                v.add(cat, sc)
        direction, cats = v.result()
        if direction == 0:
            self.audit.log(now, modes[0], "NO_TRADE", NT.NO_DIRECTION_VOTE)
            return {"action": "NO_TRADE", "reason": NT.NO_DIRECTION_VOTE}

        # 5) wall engagement (P1/P2/P4 directional need a wall story)
        snap = self.md.last()
        engaged = self.walls.on_snap(snap) if snap else False
        if not engaged:
            self.audit.log(now, modes[0], "NO_TRADE", NT.WALL_NOT_ENGAGED)
            return {"action": "NO_TRADE", "reason": NT.WALL_NOT_ENGAGED}

        # 6) THE 4-LAYER STACK (mirror = direction < 0)
        ok, fail, ev = self.stack.evaluate(self.md, now, mirror=(direction < 0))
        if not ok:
            self.audit.log(now, modes[0], "NO_TRADE", fail, ev)
            return {"action": "NO_TRADE", "reason": fail}

        # 7) persistence confirm
        if not self._persist(modes[0] + str(direction), True, now):
            self.audit.log(now, modes[0], "NO_TRADE", NT.PERSISTENCE_FAILED)
            return {"action": "NO_TRADE", "reason": NT.PERSISTENCE_FAILED}

        # 8) sizing + package
        budget = self.state.capital * MS_CONFIG["sizing"]["risk_per_trade_pct"] / 100
        prem_move = max(snap.spot * 0.004, 1.0)   # DOC-VERIFY live pricing
        size, err = compute_size(budget, prem_move,
                                 multiplier=MS_CONFIG["universe"]["lot_size"][
                                     instrument.split(":")[0]],
                                 slippage_pct=MS_CONFIG["sizing"]["slippage_buffer_pct"],
                                 fees=MS_CONFIG["sizing"]["fees_per_order"])
        if err:
            self.audit.log(now, modes[0], "NO_TRADE", err)
            return {"action": "NO_TRADE", "reason": err}
        mode = modes[0]
        pkg = Package(mode, instrument, direction,
                      entry=snap.spot, stop=snap.spot - 1,
                      target=snap.spot + prem_move,
                      hold_minutes=MS_CONFIG["stops"]["time_stop_minutes"][mode],
                      risk_amt=size["actual_risk"], lots=size["lots"],
                      evidence={"stack": ev, "votes": cats}, ts=now,
                      hedge={"fraction": MS_CONFIG["p4"]["hedge_fraction_of_primary"],
                             "trigger_r": MS_CONFIG["p4"]["profit_expansion_trigger_r"]}
                      if mode == "P4" else None)
        self.audit.log(now, mode, "SIGNAL", "package_ready",
                       {"lots": size["lots"], "stack": ev})
        return {"action": "APPROVAL_REQUIRED", "package": pkg, "mode": mode}

    def on_approval(self, pkg, now, yes):
        if not yes:
            self.audit.log(now, pkg.mode, "NO_TRADE", NT.APPROVAL_MISSING)
            return {"action": "NO_TRADE", "reason": NT.APPROVAL_MISSING}
        if pkg.expired:
            self.audit.log(now, pkg.mode, "NO_TRADE", NT.APPROVAL_EXPIRED)
            return {"action": "NO_TRADE", "reason": NT.APPROVAL_EXPIRED}
        pkg.approve(now)
        self.state.trades_today += 1
        self.state.open_pos.append({"instrument": pkg.instrument,
                                    "mode": pkg.mode, "pkg": pkg})
        self.audit.log(now, pkg.mode, "ENTRY", "approved",
                       {"lots": pkg.lots})
        return {"action": "ENTERED", "legs": LegMachine(now, pkg.mode == "P3")}

    def request_hedge(self, pkg, spec, now):
        if pkg.hedge_pre_approved(spec):
            self.audit.log(now, "P4", "ENTRY", "hedge_pre_approved")
            return {"action": "HEDGE_OK"}
        return {"action": "HEDGE_NEEDS_APPROVAL",
                "reason": NT.APPROVAL_MISSING}
