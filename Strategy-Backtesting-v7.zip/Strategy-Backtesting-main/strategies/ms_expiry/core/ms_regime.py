# ms_regime.py — binding pre-classification: PINNING / TREND / MIXED
from ms_config import MS_CONFIG
import ms_no_trade as NT


class Regime:
    # classified once pre-market (+max 1 re-classify); drives mode blocking.
    def __init__(self):
        self.state = "UNCLASSIFIED"
        self.reclassify_used = 0

    def classify(self, md, gap_pct, fii_cash_net, fii_fut_adds_same_dir,
                 maxpain_shift_pts, iv_vs_avg):
        r = MS_CONFIG["regime"]
        snap = md.last()
        if snap is None:
            self.state = "UNCLASSIFIED"
            return
        cw, pw = snap.walls()
        mp = snap.max_pain()
        if cw is None or pw is None or mp is None:
            self.state = "MIXED"
            return
        sym = abs(cw - pw) / snap.spot * 100
        pin_dist = abs(snap.spot - mp) / snap.spot * 100
        pinning = (sym <= r["wall_symmetry_max_pct"]
                   and pin_dist <= r["pin_maxpain_dist_pct"]
                   and abs(gap_pct) < r["gap_trend_pct"] / 2
                   and iv_vs_avg <= r["iv_vs_avg_ratio"])
        trend = (abs(gap_pct) >= r["gap_trend_pct"]
                 and fii_fut_adds_same_dir
                 and abs(maxpain_shift_pts) >= r["maxpain_shift_pts"])
        if pinning:
            self.state = "PINNING"      # directional blocked; P3 spreads only
        elif trend:
            self.state = "TREND"        # directional playbook
        else:
            self.state = "MIXED"        # lock after 1 re-classify

    def reclassify(self, md, *args):
        if self.reclassify_used >= MS_CONFIG["regime"]["mixed_reclassify_allowed"]:
            self.state = "MIXED_LOCK"
            return False
        self.reclassify_used += 1
        self.classify(md, *args)
        return True

    def directional_allowed(self):
        return self.state == "TREND"
