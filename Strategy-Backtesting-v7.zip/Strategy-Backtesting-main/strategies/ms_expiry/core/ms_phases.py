# ms_phases.py — time-phase + SUPREME cutoff (only authority in codebase)
from datetime import time as dtime

from ms_config import MS_CONFIG


def _t(s):
    h, m = s.split(":")
    return dtime(int(h), int(m))


class Phases:
    def __init__(self):
        p = MS_CONFIG["phases"]
        self.p1 = (_t(p["p1"][0]), _t(p["p1"][1]))
        self.p2 = (_t(p["p2"][0]), _t(p["p2"][1]))
        self.gap = (_t(p["gap"][0]), _t(p["gap"][1]))
        self.p4 = (_t(p["p4_obs"][0]), _t(p["p4_obs"][1]))
        self.p4_cutoff = _t(p["p4_entry_cutoff"])
        self.square_off = _t(p["final_square_off"])
        self.open = _t(p["market_open"])

    def modes_for(self, t):
        if t < self.open:
            return "PRE", []
        if self.p1[0] <= t < self.p1[1]:
            return "EARLY", ["P1"]
        if self.p2[0] <= t < self.p2[1]:
            return "MID", ["P2"]
        if self.gap[0] <= t < self.gap[1]:
            return "GAP", []          # explicit: no mode, monitoring only
        if self.p4[0] <= t < self.p4[1]:
            return "LATE_OBS", ["P4"]
        return "LATE_MGMT", []

    def p4_entry_ok(self, t):
        return self.p4[0] <= t < self.p4_cutoff

    def past_square_off(self, t):
        return t >= self.square_off
