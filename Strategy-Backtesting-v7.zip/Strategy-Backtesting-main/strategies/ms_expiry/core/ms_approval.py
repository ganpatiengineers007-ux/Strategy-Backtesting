# ms_approval.py — YES gate + P4 hedge pre-approval (no bypass, any mode)
from ms_config import MS_CONFIG
import ms_no_trade as NT


class Package:
    def __init__(self, mode, instrument, direction, entry, stop, target,
                 hold_minutes, risk_amt, lots, evidence, ts, hedge=None):
        self.mode, self.instrument, self.direction = mode, instrument, direction
        self.entry, self.stop, self.target = entry, stop, target
        self.hold_minutes, self.risk_amt, self.lots = hold_minutes, risk_amt, lots
        self.evidence, self.ts = evidence, ts
        self.hedge = hedge       # pre-specified contingent hedge spec
        self.approved = False
        self.expired = False
        self.ts_ok = None

    def approve(self, ts):
        self.approved, self.ts_ok = True, ts

    def valid(self, now, price, risk_now):
        if self.expired or not self.approved:
            return False
        if abs(price - self.entry) / max(self.entry, 1e-9) > 0.005:
            self.expired = True
            return False
        if abs(risk_now - self.risk_amt) / max(self.risk_amt, 1e-9) > 0.20:
            self.expired = True
            return False
        if (now - self.ts_ok).total_seconds() > self.hold_minutes * 60:
            self.expired = True
            return False
        return True

    def hedge_pre_approved(self, spec):
        if not MS_CONFIG["p4"]["hedge_pre_approval"] or not self.hedge:
            return False
        c = self.hedge
        return (abs(spec["fraction"] - c["fraction"]) <= 0.02
                and spec["trigger_r"] >= c["trigger_r"])
