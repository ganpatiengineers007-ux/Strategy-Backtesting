# ms_config.py — MS Expiry Specialist v3.0
# Every threshold measurable. RESEARCH items must be frozen by backtest.

MS_CONFIG = {
    "brand": "MS",
    "version": "3.0",

    # ---------------- universe ----------------
    "universe": {
        "allowed": ["NIFTY", "BANKNIFTY", "SENSEX"],
        "lot_size": {"NIFTY": 75, "BANKNIFTY": 35, "SENSEX": 20},
        "strike_step": {"NIFTY": 50, "BANKNIFTY": 100, "SENSEX": 100},
        "max_spread_pct_of_premium": 0.05,
        "min_chain_strikes": 21,
    },

    # ---------------- phases (supreme cutoff lives ONLY in ms_phases.py) ----
    "phases": {
        "market_open": "09:15",
        "p1": ("09:15", "10:30"),
        "p2": ("10:30", "12:30"),
        "gap": ("12:30", "14:40"),
        "p4_obs": ("14:40", "15:00"),
        "p4_entry_cutoff": "15:00",
        "final_square_off": "15:20",
    },

    # ---------------- regime pre-classification (binding) ----------------
    "regime": {
        "wall_symmetry_max_pct": 0.40,     # call/put max-OI spread vs spot
        "pin_maxpain_dist_pct": 0.30,     # spot within X% of max pain
        "gap_trend_pct": 0.70,            # overnight gap
        "maxpain_shift_pts": 100,         # 2-session shift => trend
        "iv_vs_avg_ratio": 1.00,          # ATM IV vs 4-expiry avg
        "mixed_reclassify_allowed": 1,
    },

    # ---------------- 4-layer entry stack (MS quant core) ----------------
    "stack": {
        # L1: delta-weighted OI
        "otm_call_oi_drop_pct": 8.0,          # per 5-min snapshot pair
        "deep_itm_put_oi_surge_pct": 5.0,
        "deep_itm_delta_min": 0.70,
        # L2: velocity
        "unwind_velocity_pct_5min": 5.0,      # below => rollover
        # L3: volume/OI
        "volume_oi_ratio_min": 1.50,          # below => noise
        # L4: tick gate
        "tick_window_sec": 180,
        "ask_bid_dominance_min": 1.40,        # bid-hit => FAKEOUT reject
        "cvd_agree_min": 0.0,                 # session CVD must not oppose
        # Vanna (post 13:15 only)
        "vanna_iv_drop_bps": 25,
        # wall mechanics
        "wall_approach_pct": 0.20,
        "wall_break_pct": 0.10,
        "wall_min_tests": 2,
    },

    # ---------------- confluence ----------------
    "confluence": {
        "min_independent_votes": 2,
        "min_vote_score": 0.35,
        "correlated_pairs": [["positioning", "greeks_energy"]],
        "direction_categories": ["structure", "flow", "positioning"],
    },

    # ---------------- persistence ----------------
    "persistence": {
        "min_confirm_seconds": 30,
        "regime_reversal_confirm_seconds": 45,
    },

    # ---------------- sizing (slippage explicit) ----------------
    "sizing": {
        "risk_per_trade_pct": 1.0,
        "slippage_buffer_pct": 0.10,
        "fees_per_order": 20.0,
        "taxes_pct": 0.05,
        "single_leg_shrink_only": True,
    },

    # ---------------- stops / exits ----------------
    "stops": {
        "absolute_cap_pct_of_premium": 50.0,   # RESEARCH
        "time_stop_minutes": {"P1": 45, "P2": 30, "P3": 90, "P4": 25},
        "trail_target1_book_pct": 0.50,
    },

    # ---------------- legs ----------------
    "legs": {
        "leg2_fill_timeout_sec": 20,
        "leg2_partial_fill_wait_sec": 10,
    },

    # ---------------- P4 ----------------
    "p4": {
        "hedge_fraction_of_primary": 0.25,
        "profit_expansion_trigger_r": 1.0,
        "hedge_pre_approval": True,
    },

    # ---------------- daily controls ----------------
    "daily": {
        "max_trades_per_day": 6,
        "max_consecutive_losses": 3,
        "max_open_positions": 2,
        "max_daily_loss_pct": 2.0,
    },

    # ---------------- DQ gate ----------------
    "dq": {
        "chain_max_age_sec": 180,
        "tick_max_age_sec": 5,
        "min_iv_surface_strikes": 15,
        "iv_surface_max_gap_steps": 2,
    },

    # ---------------- RESEARCH placeholders (Sec-19 style, enforceable) ----
    "research": {
        "event_blackout": {"events": [], "minutes_before": 30,
                            "minutes_after": 30},
        "latency_budget_ms": {"market_data": 500, "broker_ws": 800,
                                "end_to_end": 1500},
    },
}
