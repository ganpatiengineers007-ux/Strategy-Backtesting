# ms_legs.py — leg-risk state machine with LEG_2_PARTIAL
from datetime import datetime, timedelta

from ms_config import MS_CONFIG
import ms_no_trade as NT


class LegMachine:
    def __init__(self, now, is_spread):
        self.state = "ENTRY_PENDING"
        self.is_spread = is_spread
        self.deadline = now + timedelta(
            seconds=MS_CONFIG["legs"]["leg2_fill_timeout_sec"])
        self.leg2_expected = 0
        self.leg2_filled = 0
        self.partial_deadline = None

    def leg1_filled(self, now):
        self.state = "LEG_2_PENDING"
        self.deadline = now + timedelta(
            seconds=MS_CONFIG["legs"]["leg2_fill_timeout_sec"])

    def leg2(self, lots, now):
        if lots >= self.leg2_expected:
            self.state = "HEDGE_ACTIVE"
            self.leg2_filled = lots
            return
        self.state = "LEG_2_PARTIAL"
        self.leg2_filled = lots
        if self.partial_deadline is None:
            self.partial_deadline = now + timedelta(
                seconds=MS_CONFIG["legs"]["leg2_partial_fill_wait_sec"])

    def tick(self, now):
        if self.state == "LEG_2_PENDING" and now >= self.deadline:
            self.state = "EMERGENCY_EXIT"
            return "EMERGENCY_CLOSE_LEG1", NT.LEG2_TIMEOUT
        if self.state == "LEG_2_PARTIAL":
            if self.leg2_filled >= self.leg2_expected:
                self.state = "HEDGE_ACTIVE"
            elif now >= self.partial_deadline:
                self.state = "EMERGENCY_EXIT"
                return "EMERGENCY_CLOSE_LEG1", NT.LEG2_TIMEOUT
        if self.state == "EMERGENCY_EXIT":
            return "EMERGENCY_CLOSE_LEG1", NT.LEG2_TIMEOUT
        return "", None
