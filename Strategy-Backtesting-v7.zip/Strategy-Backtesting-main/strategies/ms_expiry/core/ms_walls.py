# ms_walls.py — wall engine: engagement, hold/break, tests
from ms_config import MS_CONFIG


class WallEngine:
    def __init__(self):
        self.tests = 0

    def engaged(self, snap):
        # spot within approach distance of call wall
        cw, _ = snap.walls()
        if cw is None:
            return False, None
        ap = MS_CONFIG["stack"]["wall_approach_pct"] / 100
        return snap.spot >= cw * (1 - ap), cw

    def broken(self, snap, cw):
        br = MS_CONFIG["stack"]["wall_break_pct"] / 100
        return snap.spot >= cw * (1 + br)

    def on_snap(self, snap):
        # count tests: spot approached wall then pulled back
        eng, cw = self.engaged(snap)
        if eng and cw is not None:
            br = MS_CONFIG["stack"]["wall_break_pct"] / 100
            if snap.spot < cw * (1 + br):
                self.tests += 1
        return self.tests >= MS_CONFIG["stack"]["wall_min_tests"]
