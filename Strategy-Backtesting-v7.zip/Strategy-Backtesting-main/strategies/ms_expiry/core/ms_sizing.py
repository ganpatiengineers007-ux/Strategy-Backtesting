# ms_sizing.py — Actual Risk = Lots x Multiplier x PremiumMove + Slip + Fees
from ms_config import MS_CONFIG
import ms_no_trade as NT


def compute_size(budget, premium_move, multiplier, slippage_pct, fees):
    unit = multiplier * premium_move
    per_lot = unit * (1 + slippage_pct) + fees
    if per_lot <= 0:
        return None, NT.STOP_UNDEFINED
    lots = int(budget // per_lot)          # floor only, never round up
    if lots < 1:
        return None, NT.RR_INVALID
    return {"lots": lots, "per_lot": per_lot,
            "actual_risk": lots * per_lot}, None


def margin_gate(single_leg, lots, margin_avail, margin_per_lot):
    if lots * margin_per_lot <= margin_avail:
        return lots, None
    shrunk = int(margin_avail // margin_per_lot) if margin_per_lot > 0 else 0
    if single_leg and shrunk >= 1:
        return shrunk, NT.MARGIN_SHORTFALL_SINGLE_LEG_SHRUNK
    if single_leg:
        return 0, NT.RISK_LIMIT
    return None, NT.MARGIN_SHORTFALL_MULTILEG_NO_TRADE
