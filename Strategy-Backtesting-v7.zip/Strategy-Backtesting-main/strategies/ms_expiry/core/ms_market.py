# ms_market.py — chain features, walls, pin, DQ, GEX-energy, ticks
from datetime import datetime
from typing import Optional
import math

from ms_config import MS_CONFIG
import ms_no_trade as NT


class StrikeRow:
    def __init__(self, strike, ce_oi, pe_oi, ce_iv, pe_iv,
                 ce_ltp, pe_ltp, ce_vol, pe_vol):
        self.strike = strike
        self.ce_oi, self.pe_oi = ce_oi, pe_oi
        self.ce_iv, self.pe_iv = ce_iv, pe_iv
        self.ce_ltp, self.pe_ltp = ce_ltp, pe_ltp
        self.ce_vol, self.pe_vol = ce_vol, pe_vol


class ChainSnap:
    def __init__(self, ts, spot, rows):
        self.ts = ts
        self.spot = spot
        self.rows = {r.strike: r for r in rows}

    def walls(self):
        cw = max(self.rows.items(), key=lambda kv: kv[1].ce_oi, default=None)
        pw = max(self.rows.items(), key=lambda kv: kv[1].pe_oi, default=None)
        return (cw[0] if cw else None, pw[0] if pw else None)

    def max_pain(self):
        best, bp = None, None
        for s in sorted(self.rows):
            pain = sum((s - k) * r.ce_oi for k, r in self.rows.items() if s > k)                  + sum((k - s) * r.pe_oi for k, r in self.rows.items() if s < k)
            if bp is None or pain < bp:
                best, bp = s, pain
        return best

    def nearest_active_strike(self):
        c = [(abs(k - self.spot), k) for k, r in self.rows.items()
             if r.ce_oi + r.pe_oi > 0]
        return min(c)[1] if c else None

    def avg_atm_iv(self):
        ns = self.nearest_active_strike()
        if ns is None:
            return 0.0
        r = self.rows[ns]
        v = [x for x in (r.ce_iv, r.pe_iv) if x > 0]
        return sum(v) / len(v) if v else 0.0

    def otm_call_oi(self):
        return {k: r.ce_oi for k, r in self.rows.items() if k > self.spot}

    def deep_itm_puts(self, delta_min):
        # approx put delta via moneyness; deep ITM = |delta| >= delta_min
        out = {}
        for k, r in self.rows.items():
            if k >= self.spot:
                continue
            m = (k - self.spot) / (self.spot * 0.01)
            d = 1.0 / (1.0 + math.exp(1.6 * m))
            if d >= delta_min:
                out[k] = r.pe_oi
        return out


class MarketData:
    def __init__(self):
        self.chain = []
        self.ticks = []          # (ts, side 'A'/'B', qty, price)
        self.cvd = 0.0
        self.spot = 0.0
        self.spot_ts = None

    def on_chain(self, snap: ChainSnap):
        self.chain.append(snap)
        if len(self.chain) > 60:
            self.chain.pop(0)
        self.spot = snap.spot
        self.spot_ts = snap.ts

    def on_tick(self, ts, side, qty, price):
        self.ticks.append((ts, side.upper()[:1], qty, price))
        if len(self.ticks) > 50000:
            self.ticks.pop(0)
        self.cvd += qty if side.upper()[:1] == "A" else -qty

    def last(self, n=1):
        if not self.chain:
            return None
        return self.chain[-n]

    def two_snaps(self):
        # returns (prev, cur) or None
        if len(self.chain) < 2:
            return None
        return (self.chain[-2], self.chain[-1])

    def dq(self, now):
        c = MS_CONFIG["dq"]
        snap = self.last()
        out = {"ok": False, "chain_fresh": False, "iv_ok": False}
        if snap is None:
            return out
        out["chain_fresh"] = (now - snap.ts).total_seconds() <= c["chain_max_age_sec"]
        ivk = sorted(k for k, r in snap.rows.items()
                     if r.ce_iv > 0 and r.pe_iv > 0)
        out["iv_ok"] = len(ivk) >= c["min_iv_surface_strikes"]
        out["ok"] = out["chain_fresh"] and len(snap.rows) >=             MS_CONFIG["universe"]["min_chain_strikes"]
        return out

    def tick_dominance(self, now):
        w = MS_CONFIG["stack"]["tick_window_sec"]
        a = b = 0
        for ts, side, qty, _ in reversed(self.ticks):
            if (now - ts).total_seconds() > w:
                break
            if side == "A":
                a += qty
            else:
                b += qty
        return a, b

    def gex_energy(self):
        # magnitude only — NEVER direction. DOC-VERIFY convention.
        snap = self.last()
        if snap is None:
            return None
        t = 0.0
        for k, r in snap.rows.items():
            otm = max(k - snap.spot, 0) if r.ce_oi >= r.pe_oi else max(snap.spot - k, 0)
            t += (r.ce_oi - r.pe_oi) * otm
        return t

    def pin_ratio(self, minutes_left):
        # pin-distance normalized by IV expected move
        snap = self.last()
        if snap is None or minutes_left <= 0:
            return None
        ns = snap.nearest_active_strike()
        if ns is None:
            return None
        iv = snap.avg_atm_iv() / 100.0
        if iv <= 0:
            return None
        exp_move = snap.spot * iv * math.sqrt(max(minutes_left, 1) / (252 * 375))
        if exp_move <= 0:
            return None
        return abs(snap.spot - ns) / exp_move
