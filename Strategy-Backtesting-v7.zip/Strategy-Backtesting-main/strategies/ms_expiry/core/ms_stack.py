# ms_stack.py — THE 4-LAYER QUANT ENTRY STACK (MS core)
# OI is BIAS (3-5 min delayed). Ticks are ENTRY AUTHORITY.
from datetime import datetime

from ms_config import MS_CONFIG
import ms_no_trade as NT


class EntryStack:
    # Returns (passed, failing_code, evidence) for a LONG (call-wall unwind)
    # trade. Mirror logic for SHORT via mirror=True.
    def __init__(self):
        self.evidence = {}

    def evaluate(self, md, now, mirror=False):
        cfg = MS_CONFIG["stack"]
        pair = md.two_snaps()
        if pair is None:
            return False, NT.DATA_STALE, {}
        prev, cur = pair
        self.evidence = {}

        # ---- L1: delta-weighted OI ----
        if not mirror:
            otm_prev = {k: prev.rows[k].ce_oi for k in prev.otm_call_oi()}
            drops = {}
            for k, oi_prev in otm_prev.items():
                if k in cur.rows and oi_prev > 0:
                    d = (oi_prev - cur.rows[k].ce_oi) / oi_prev * 100
                    if d >= cfg["otm_call_oi_drop_pct"]:
                        drops[k] = d
            surges = {}
            prev_deep = prev.deep_itm_puts(cfg["deep_itm_delta_min"])
            cur_deep = cur.deep_itm_puts(cfg["deep_itm_delta_min"])
            for k, oi_p in prev_deep.items():
                if k in cur_deep and oi_p > 0:
                    s = (cur_deep[k] - oi_p) / oi_p * 100
                    if s >= cfg["deep_itm_put_oi_surge_pct"]:
                        surges[k] = s
            if not drops or not surges:
                return False, NT.L1_DELTA_OI_FAIL, {}
            self.evidence["l1_drops"] = drops
            self.evidence["l1_surges"] = surges
            top_unwind = max(drops, key=drops.get)
        else:
            # mirror: OTM PUT unwind + deep-ITM CALL surge
            otm_puts_prev = {k: prev.rows[k].pe_oi
                             for k, r in prev.rows.items() if k < prev.spot}
            drops = {}
            for k, oi_p in otm_puts_prev.items():
                if k in cur.rows and oi_p > 0:
                    d = (oi_p - cur.rows[k].pe_oi) / oi_p * 100
                    if d >= cfg["otm_call_oi_drop_pct"]:
                        drops[k] = d
            surges = {}
            prev_deep = {k: prev.rows[k].ce_oi for k, r in prev.rows.items()
                         if prev.spot - k >= prev.spot * 0.015}
            cur_deep = {k: cur.rows[k].ce_oi for k, r in cur.rows.items()
                        if cur.spot - k >= cur.spot * 0.015}
            for k, oi_p in prev_deep.items():
                if k in cur_deep and oi_p > 0:
                    s = (cur_deep[k] - oi_p) / oi_p * 100
                    if s >= cfg["deep_itm_put_oi_surge_pct"]:
                        surges[k] = s
            if not drops or not surges:
                return False, NT.L1_DELTA_OI_FAIL, {}
            self.evidence["l1_drops"] = drops
            self.evidence["l1_surges"] = surges
            top_unwind = max(drops, key=drops.get)

        # ---- L2: unwinding velocity at top strike ----
        side = "ce_oi" if not mirror else "pe_oi"
        oi_prev = getattr(prev.rows.get(top_unwind), side, 0)
        oi_cur = getattr(cur.rows.get(top_unwind), side, 0)
        if oi_prev <= 0:
            return False, NT.L2_VELOCITY_FAIL, {}
        vel = (oi_prev - oi_cur) / oi_prev * 100
        if vel < cfg["unwind_velocity_pct_5min"]:
            return False, NT.L2_VELOCITY_FAIL, {}
        self.evidence["velocity_pct"] = round(vel, 2)

        # ---- L3: volume/OI at the wall ----
        cw, pw = cur.walls()
        wall = (pw if mirror else cw)
        if wall is None or wall not in cur.rows:
            return False, NT.WALL_NOT_ENGAGED, {}
        row = cur.rows[wall]
        vol = row.pe_vol if mirror else row.ce_vol
        oi = row.pe_oi if mirror else row.ce_oi
        voi = vol / oi if oi > 0 else 0.0
        if voi < cfg["volume_oi_ratio_min"]:
            return False, NT.L3_VOLUME_OI_FAIL, {}
        self.evidence["v_oi"] = round(voi, 2)

        # ---- Vanna: post-13:15 IV alignment ----
        if now.hour * 60 + now.minute >= 13 * 60 + 15:
            iv_now = [r.ce_iv for r in cur.rows.values() if r.ce_iv > 0]
            iv_prev = [r.ce_iv for r in prev.rows.values() if r.ce_iv > 0]
            if iv_now and iv_prev:
                move_bps = (sum(iv_now)/len(iv_now) - sum(iv_prev)/len(iv_prev)) * 100
                aligned = move_bps <= -cfg["vanna_iv_drop_bps"]
                if not aligned:
                    return False, NT.VANNA_MISALIGNED, {}
            self.evidence["vanna_checked"] = True

        # ---- L4: tick gate (entry authority) ----
        a, b = md.tick_dominance(now)
        if b <= 0:
            ratio = 99.0 if a > 0 else 0.0
        else:
            ratio = a / b
        if mirror:
            # short side: seller dominance is bid-side aggressive
            ratio = (b / a) if a > 0 else (99.0 if b > 0 else 0.0)
        if ratio < 1.0:
            return False, NT.L4_TICK_FAKEOUT, {}   # bid-hit = fakeout
        if ratio < cfg["ask_bid_dominance_min"]:
            return False, NT.L4_CVD_CONFLICT, {}
        # session CVD must not oppose
        if not mirror and md.cvd < cfg["cvd_agree_min"]:
            return False, NT.L4_CVD_CONFLICT, {}
        if mirror and md.cvd > -cfg["cvd_agree_min"]:
            return False, NT.L4_CVD_CONFLICT, {}
        self.evidence["tick_ratio"] = round(ratio, 2)

        return True, None, self.evidence
