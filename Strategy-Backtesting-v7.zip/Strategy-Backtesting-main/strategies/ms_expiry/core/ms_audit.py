# ms_audit.py — every signal + rejection recorded with code
class AuditLog:
    def __init__(self):
        self.rows = []

    def log(self, ts, mode, event, reason, payload=None):
        self.rows.append({"ts": ts, "mode": mode, "event": event,
                          "reason": reason, "payload": payload or {}})

    def tail(self, n=50):
        return self.rows[-n:]
