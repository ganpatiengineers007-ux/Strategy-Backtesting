"""Bridge: external quantlab strategies (positions(data) -> target exposure per row) ko engine ke on_bar() se jodta hai.

Contract (external base.py): positions() row t ka faisla sirf row t tak ke data par. Isliye hum poore series ka
positions ek baar banakar cache karte hain, aur on_bar me sirf t-th value dekhte hain (no lookahead).
v0 engine long-only hai: position >0 -> BUY (entry), <=0 after long -> EXIT.
"""
from datetime import datetime
from zoneinfo import ZoneInfo

import numpy as np

from strategies.base import Strategy
from strategies.models import Signal


def _epoch(ts, tz):
    s = str(ts).strip().replace(" ", "T")
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:  # CSV me naive local (exchange) time hota hai
        dt = dt.replace(tzinfo=ZoneInfo(tz))
    return dt.timestamp()


class BarsView:
    """external strategies ke liye: n, ts (UTC epoch), open, high, low, close, volume arrays."""

    def __init__(self, bars, tz="Asia/Kolkata"):
        self.n = len(bars)
        self.ts = np.array([_epoch(b.ts, tz) for b in bars], dtype=float)
        self.open = np.array([b.open for b in bars], dtype=float)
        self.high = np.array([b.high for b in bars], dtype=float)
        self.low = np.array([b.low for b in bars], dtype=float)
        self.close = np.array([b.close for b in bars], dtype=float)
        self.volume = np.array([b.volume for b in bars], dtype=float)


class PrecomputedLongAdapter(Strategy):
    exchange_tz = "Asia/Kolkata"
    required_data = ()

    def __init__(self, params=None):
        super().__init__(params)
        self._key = None
        self._pos = None

    def _positions(self, view):  # subclass: external strategy ka positions() call karo
        raise NotImplementedError

    def _ensure(self, bars):
        key = (id(bars), len(bars))
        if key != self._key:
            pos = self._positions(BarsView(bars, self.exchange_tz))
            self._pos = np.nan_to_num(np.asarray(pos, dtype=float))
            self._key = key
        return self._pos

    def on_bar(self, ctx):
        pos = self._ensure(ctx._bars)
        i = ctx.index
        cur = pos[i]
        prev = pos[i - 1] if i > 0 else 0.0
        if cur > 0 and prev <= 0:
            return Signal("BUY", reason=f"{self.strategy_id} entry")
        if cur <= 0 and prev > 0:
            return Signal("EXIT", reason=f"{self.strategy_id} exit")
        return None


def not_wired(strategy_id, needs):
    """Jo adapter abhi external code se nahi juda, woh silently 0 trades nahi dega; saaf error dega."""
    raise NotImplementedError(f"{strategy_id}: adapter abhi wired nahi (needs: {', '.join(needs) or 'bar data'}). "
                              "external strategy ko on_bar se jodna baki hai.")
