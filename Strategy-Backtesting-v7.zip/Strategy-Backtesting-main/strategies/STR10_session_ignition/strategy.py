"""Adapter for STR10 session_ignition (external quantlab S10). OHLCV bars par chalta hai (session = UTC minutes)."""
import sys
from pathlib import Path

_EXTERNAL_ROOT = Path(__file__).resolve().parent.parent.parent / "external"
if str(_EXTERNAL_ROOT) not in sys.path:
    sys.path.insert(0, str(_EXTERNAL_ROOT))

from strategies._bridge import PrecomputedLongAdapter  # noqa: E402
from gts_quant_lab.gts_quant_lab.quantlab.strategies.s10_session_ignition import SessionIgnitionStrategy  # noqa: E402


class SessionIgnitionAdapter(PrecomputedLongAdapter):
    strategy_id = "session_ignition"
    required_data = ()

    def __init__(self, params=None):
        super().__init__(params)
        self._inner = SessionIgnitionStrategy()

    def _positions(self, view):
        return self._inner.positions(view)
