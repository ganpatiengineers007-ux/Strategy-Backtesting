"""Adapter for STR08 fvg (external quantlab S08). OHLCV bars par chalta hai. Bridge se engine se juda."""
import sys
from pathlib import Path

_EXTERNAL_ROOT = Path(__file__).resolve().parent.parent.parent / "external"
if str(_EXTERNAL_ROOT) not in sys.path:
    sys.path.insert(0, str(_EXTERNAL_ROOT))

from strategies._bridge import PrecomputedLongAdapter  # noqa: E402
from gts_quant_lab.gts_quant_lab.quantlab.strategies.s08_fvg import FVGStrategy  # noqa: E402


class FVGAdapter(PrecomputedLongAdapter):
    strategy_id = "fvg"
    required_data = ()

    def __init__(self, params=None):
        super().__init__(params)
        self._inner = FVGStrategy()

    def _positions(self, view):
        return self._inner.positions(view)
