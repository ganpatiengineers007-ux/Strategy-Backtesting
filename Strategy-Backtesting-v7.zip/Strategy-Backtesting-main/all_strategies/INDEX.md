# Strategy Index (catalog)

यह फ़ोल्डर सिर्फ़ सूची है। असली code इन जगहों पर है:

| ID | Strategy | असली जगह |
|---|---|---|
| G01 | gamma_vwap | strategies/G01_gamma_vwap/ (core: all_strategies/greeks/gamma_vwap_strategy.py) |
| G02 | delta_vwap | strategies/G02_delta_vwap/ |
| G03 | vega_iv | strategies/G03_vega_iv/ |
| G04 | theta_straddle | strategies/G04_theta_straddle/ (data: option_chain) |
| G05 | greeks_confluence | strategies/G05_greeks_confluence/ |
| STR01 | obi_delta | strategies/STR01_obi_delta/ (data: L2 depth) |
| STR02 | stat_arb | strategies/STR02_stat_arb/ (data: pair) |
| STR03 | latency_arb | strategies/STR03_latency_arb/ (data: venues) |
| STR04 | microstructure | strategies/STR04_microstructure/ (data: trades) |
| STR05 | spoof_ml | strategies/STR05_spoof_ml/ (data: order events) |
| STR06 | volume_profile | strategies/STR06_volume_profile/ (data: trades) |
| STR07 | reversal_ai | strategies/STR07_reversal_ai/ (data: L2 depth) |
| STR08 | fvg | strategies/STR08_fvg/ |
| STR09 | iceberg | strategies/STR09_iceberg/ (data: order events) |
| STR10 | session_ignition | strategies/STR10_session_ignition/ |
| STR11 | mean_reversion | strategies/STR11_mean_reversion/ (अधूरी) |
| gamma_blast | gamma_blast | strategies/gamma_blast/ (data: option_chain) |
| three_pm_momentum | three_pm_momentum | strategies/three_pm_momentum/ |
| sweep | sweep | strategies/sweep/ (पहले scripts/sweep_strategy.py से जुड़ा था) |

पुराने symlink फ़ोल्डर (by_number, quantlab, quantstrat, sweep) हटा दिए गए, क्योंकि वे टूटे imports दिखाते थे।
