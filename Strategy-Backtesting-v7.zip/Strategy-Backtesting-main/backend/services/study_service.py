"""Study/results ka service layer (koi FastAPI nahi, isliye seedha test hota hai).
Registry (strategies ka list + data requirement), results.db (latest, history, run detail)."""
import json
from pathlib import Path

from results import store

ROOT = Path(__file__).resolve().parents[2]


def registry_overview(strategies_dir=None):
    from pipeline.study import discover_safe
    reg, errors = discover_safe(Path(strategies_dir) if strategies_dir else ROOT / "strategies")
    out = []
    for sid in sorted(reg.records):
        m = reg.records[sid]["manifest"]
        out.append({"strategy_id": sid, "version": str(m.get("version", "")),
                    "entry_point": m.get("entry_point", ""),
                    "required_data": list(m.get("required_data") or []),
                    "dir": reg.records[sid]["dir"].name})
    return {"strategies": out, "load_errors": errors}


def latest_results(db_path=None):
    conn = store.connect(db_path)
    try:
        return store.all_latest(conn)
    finally:
        conn.close()


def strategy_history(strategy_id, db_path=None):
    conn = store.connect(db_path)
    try:
        return store.strategy_history(conn, strategy_id)
    finally:
        conn.close()


def study_detail(study_id, db_path=None):
    conn = store.connect(db_path)
    try:
        st = conn.execute("SELECT * FROM studies WHERE study_id=?", (study_id,)).fetchone()
        if st is None:
            return None
        res = [dict(r) for r in conn.execute("SELECT * FROM results WHERE study_id=? ORDER BY rank", (study_id,))]
        runs = [dict(r) for r in conn.execute(
            "SELECT strategy_id, dataset_id, dataset_hash, bars, engine_status, reason, validation_status, gate_pass "
            "FROM dataset_runs WHERE study_id=? ORDER BY strategy_id, dataset_id", (study_id,))]
        return {"study": dict(st), "results": res, "dataset_runs": runs}
    finally:
        conn.close()


def dataset_run_detail(study_id, strategy_id, db_path=None):
    conn = store.connect(db_path)
    try:
        rows = [dict(r) for r in conn.execute(
            "SELECT * FROM dataset_runs WHERE study_id=? AND strategy_id=?", (study_id, strategy_id))]
        for r in rows:
            r["metrics"] = json.loads(r.pop("metrics_json") or "{}")
            r["validation_checks"] = json.loads(r.pop("validation_json") or "{}")
        return rows
    finally:
        conn.close()
