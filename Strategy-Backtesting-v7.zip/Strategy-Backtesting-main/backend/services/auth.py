"""Login users: config/users.json (sirf hashed password). Session token memory me, 12 ghante."""
import hashlib
import hmac
import json
import secrets
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
USERS = ROOT / "config" / "users.json"
ITER = 200_000
TTL = 12 * 3600
_sessions = {}


def _load():
    if USERS.exists():
        return json.loads(USERS.read_text(encoding="utf-8"))
    return {"users": {}}


def hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), ITER).hex()
    return f"pbkdf2_sha256${ITER}${salt}${digest}"


def verify_password(password, stored):
    try:
        _, it, salt, digest = stored.split("$")
    except ValueError:
        return False
    test = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), int(it)).hex()
    return hmac.compare_digest(test, digest)


def add_user(username, password, role="admin"):
    data = _load()
    if username in data["users"]:
        raise ValueError(f"user '{username}' pehle se hai")
    if len(password) < 8:
        raise ValueError("password kam se kam 8 akshar ka ho")
    data["users"][username] = {"password": hash_password(password), "role": role}
    USERS.parent.mkdir(parents=True, exist_ok=True)
    USERS.write_text(json.dumps(data, indent=2), encoding="utf-8")


def login(username, password):
    user = _load()["users"].get(username)
    if not user or not verify_password(password, user["password"]):
        return None
    token = secrets.token_urlsafe(32)
    _sessions[token] = {"user": username, "expires": time.time() + TTL}
    return token


def check_token(token):
    s = _sessions.get(token)
    if not s:
        return None
    if s["expires"] < time.time():
        _sessions.pop(token, None)
        return None
    return s["user"]


def logout(token):
    _sessions.pop(token, None)


def bearer(headers):
    auth = headers.get("authorization", "")
    return auth[7:] if auth.lower().startswith("bearer ") else ""
