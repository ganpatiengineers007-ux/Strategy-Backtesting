"""/auth/login, /auth/logout, /auth/me"""
from backend.api.common import guarded, make_router
from backend.services import auth

router = make_router()
if router is not None:
    from fastapi import Request
    from fastapi.responses import JSONResponse

    @router.post("/auth/login")
    async def login(request: Request):
        body = await request.json()
        token = auth.login(str(body.get("username", "")), str(body.get("password", "")))
        if not token:
            return JSONResponse({"error": "galat username ya password"}, status_code=401)
        return {"token": token, "expires_in": auth.TTL}

    @router.post("/auth/logout")
    async def logout(request: Request):
        auth.logout(auth.bearer(request.headers))
        return {"ok": True}

    @router.get("/auth/me")
    async def me(request: Request):
        user = auth.check_token(auth.bearer(request.headers))
        if not user:
            return JSONResponse({"error": "login karein"}, status_code=401)
        return {"user": user}
