"""/study/* routes: registry, latest results, strategy history, study detail. Auth wahi X-API-Key wala."""
from backend.api.common import guarded, make_router
from backend.services import study_service as svc

router = make_router()
if router is not None:
    router.get("/study/registry")(guarded(lambda: svc.registry_overview()))
    router.get("/study/latest")(guarded(lambda: svc.latest_results()))
    router.get("/study/strategies/{strategy_id}/history")(guarded(lambda strategy_id: svc.strategy_history(strategy_id)))
    router.get("/study/strategies/{strategy_id}/runs/{study_id}")(
        guarded(lambda strategy_id, study_id: svc.dataset_run_detail(study_id, strategy_id)))
    router.get("/study/{study_id}")(guarded(lambda study_id: svc.study_detail(study_id) or _not_found()))


def _not_found():
    from fastapi import HTTPException
    raise HTTPException(status_code=404, detail="study not found")
