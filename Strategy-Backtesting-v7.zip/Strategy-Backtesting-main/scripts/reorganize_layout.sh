#!/usr/bin/env bash
# पुराने layout (रूट में बिखरी फ़ाइलें) को नए layout में लाता है। दोबारा चलाने पर सुरक्षित।
#   cd Strategy-Backtesting-main && ./scripts/reorganize_layout.sh
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p archive/stale_zips archive/old_scripts docs/reports scripts

mvn() { [ -e "$1" ] && mv -n "$1" "$2" && echo "moved $1 -> $2" || true; }

# 1. पुरानी ZIP कॉपी
for z in fyers_hub.zip greeks_plugin.zip greeks_manifests.zip "gts_lab_strategies (1).zip" "gts_lab_strategies (2).zip"; do
  mvn "$z" archive/stale_zips/
done

# 2. bootstrap: रूट वाला नया, पुराने archive में
if [ -e bootstrap.py ]; then
  [ -e scripts/bootstrap.py ] && mv -n scripts/bootstrap.py archive/old_scripts/bootstrap_v2.1_scripts.py
  mv bootstrap.py scripts/bootstrap.py && echo "moved bootstrap.py -> scripts/"
fi
mvn scripts/bootstrap-5.py archive/old_scripts/
# 3. रूट की inspect_external (scripts वाली जैसी ही) हटाओ
if [ -e inspect_external.py ]; then rm inspect_external.py && echo "removed duplicate root inspect_external.py"; fi

# 4. रूट की स्क्रिप्ट्स -> scripts/
for s in scan_project.py audit_folders.py quant_strategy_lab.py; do mvn "$s" scripts/; done

# 5. रिपोर्ट -> docs/reports/
for r in audit_report.md scan_report.txt WIRING_REPORT.md; do mvn "$r" docs/reports/; done

# 6. स्क्रिप्ट्स के पाथ (एक बार, idempotent)
python3 - <<'PY'
import pathlib
def patch(path, pairs):
    p = pathlib.Path(path)
    if not p.exists():
        return
    s = p.read_text(encoding="utf-8"); orig = s
    for old, new in pairs:
        s = s.replace(old, new)
    if s != orig:
        p.write_text(s, encoding="utf-8"); print("patched", path)
patch("scripts/scan_project.py", [
    ('out = root / "scan_report.txt"', 'out = root / "docs" / "reports" / "scan_report.txt"\n    out.parent.mkdir(parents=True, exist_ok=True)')])
patch("scripts/audit_folders.py", [
    ('ROOT = Path(".")', 'ROOT = Path(__file__).resolve().parents[1]'),
    ('with open("audit_report.md", "w", encoding="utf-8") as f:',
     'REPORT = ROOT / "docs" / "reports" / "audit_report.md"\nREPORT.parent.mkdir(parents=True, exist_ok=True)\nwith open(REPORT, "w", encoding="utf-8") as f:')])
patch("scripts/inspect_external.py", [
    ('default=str(Path(__file__).resolve().parent))', 'default=str(Path(__file__).resolve().parents[1]))'),
    ('(root / "external_report.md")', '(root / "docs" / "external_report.md")'),
    ('(root / "external_report.json")', '(root / "docs" / "external_report.json")')])
PY
echo "DONE. जाँच: ls scripts/ docs/reports/ archive/stale_zips/"
