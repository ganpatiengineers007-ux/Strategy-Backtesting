#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python -m cli.main demo --out output
