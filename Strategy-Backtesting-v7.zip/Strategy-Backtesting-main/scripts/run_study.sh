#!/usr/bin/env bash
# Ek hi kamaan: hub se data nikaalo, phir sabhi strategies ka study chalao.
#   ./scripts/run_study.sh              # poora (validation ke saath)
#   ./scripts/run_study.sh --fast       # validation skip (sirf metrics + gates)
#   HUB_DB_PATH=/path/hub.db ./scripts/run_study.sh
set -euo pipefail
cd "$(dirname "$0")/.."
TF="${TF:-5}"
python -m cli.main hub-export --tf "$TF" --out data/hub_export
if [[ "${1:-}" == "--fast" ]]; then
  python -m cli.main study --data-dir data/hub_export --out output/study --no-validate
else
  python -m cli.main study --data-dir data/hub_export --out output/study
fi
