"""Study pipeline: Fyers hub -> backtest data -> sabhi strategies -> metrics -> gates -> export."""
