"""Fyers hub (SQLite, candles table) se backtest ke liye CSV banana.

Har symbol + timeframe ke liye ek CSV: ts,open,high,low,close,volume
- ts: hub me UTC epoch seconds hai; CSV me use `tz` (default Asia/Kolkata) ke local time me likhte hain.
- Poora history export hota hai (purana + naya dono), taaki har run ka input same rahe.
"""
import csv
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

HEADER = ["ts", "open", "high", "low", "close", "volume"]


def list_pairs(db_path, tf=None):
    """(symbol, tf, candle_count) ki list. tf diya ho to sirf wahi."""
    conn = sqlite3.connect(str(db_path), timeout=30)
    try:
        if tf is None:
            q, args = "SELECT symbol, tf, COUNT(*) FROM candles GROUP BY symbol, tf ORDER BY symbol, tf", ()
        else:
            q, args = ("SELECT symbol, tf, COUNT(*) FROM candles WHERE tf=? GROUP BY symbol, tf ORDER BY symbol", (tf,))
        return [tuple(r) for r in conn.execute(q, args).fetchall()]
    finally:
        conn.close()


def safe_name(symbol, tf):
    """'NSE:NIFTY50-INDEX' + '5' -> 'NSE_NIFTY50-INDEX_5'"""
    return f"{re.sub(r'[^A-Za-z0-9._-]+', '_', symbol)}_{re.sub(r'[^A-Za-z0-9._-]+', '_', tf)}"


def export_candles(db_path, symbol, tf, out_csv, tz="Asia/Kolkata"):
    conn = sqlite3.connect(str(db_path), timeout=30)
    try:
        rows = conn.execute(
            "SELECT ts, open, high, low, close, volume FROM candles WHERE symbol=? AND tf=? ORDER BY ts",
            (symbol, tf),
        ).fetchall()
    finally:
        conn.close()
    zone = ZoneInfo(tz)
    out = Path(out_csv)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(HEADER)
        for ts, o, h, l, c, v in rows:
            local = datetime.fromtimestamp(int(ts), timezone.utc).astimezone(zone).replace(tzinfo=None)
            w.writerow([local.isoformat(sep="T", timespec="seconds"), o, h, l, c, v if v is not None else 0])
    return {"symbol": symbol, "tf": tf, "rows": len(rows), "path": str(out)}


def export_all(db_path, out_dir, tf=None, symbol=None, tz="Asia/Kolkata"):
    """Hub ke saare (ya filter kiye) symbol/tf pairs ko out_dir me CSV bana kar do."""
    results = []
    for sym, t, _n in list_pairs(db_path, tf):
        if symbol and sym != symbol:
            continue
        path = Path(out_dir) / f"{safe_name(sym, t)}.csv"
        results.append(export_candles(db_path, sym, t, path, tz=tz))
    return results
