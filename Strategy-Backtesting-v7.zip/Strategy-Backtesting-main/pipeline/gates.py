"""Pass/fail gates aur composite score. Pure functions: koi I/O nahi, isliye alag se test hote hain."""

DEFAULT_GATES = {
    "min_trades": 30,
    "min_win_rate_pct": 40.0,
    "min_expectancy": 0.0,
    "min_total_return_pct": 0.0,
    "max_drawdown_pct": 20.0,
    "min_sharpe_daily": 0.5,
    "require_validation_pass": True,
    "require_all_datasets": True,
}

# key -> +1 matlab zyada accha, -1 matlab kam accha
DEFAULT_WEIGHTS = {
    "total_return_pct": 0.35,
    "sharpe_daily": 0.30,
    "win_rate_pct": 0.15,
    "max_drawdown_pct": 0.20,
}
DIRECTION = {"total_return_pct": +1, "sharpe_daily": +1, "win_rate_pct": +1, "max_drawdown_pct": -1}


def evaluate_gates(run, gates=None):
    """run = {status, reason, validation_status, metrics:{...}}. Returns (passed, [failure reasons])."""
    g = {**DEFAULT_GATES, **(gates or {})}
    fails = []
    if run.get("status") != "COMPLETED":
        fails.append(f"engine={run.get('status')}: {run.get('reason', '')}".strip())
        return False, fails
    m = run.get("metrics") or {}

    def num(key):
        v = m.get(key)
        return None if v is None else float(v)

    trades = num("n_trades")
    if trades is None or trades < g["min_trades"]:
        fails.append(f"trades {trades} < {g['min_trades']}")
    wr = num("win_rate_pct")
    if wr is None or wr < g["min_win_rate_pct"]:
        fails.append(f"accuracy(win_rate) {wr} < {g['min_win_rate_pct']}")
    exp = num("expectancy")
    if exp is None or exp <= g["min_expectancy"]:
        fails.append(f"expectancy {exp} <= {g['min_expectancy']}")
    ret = num("total_return_pct")
    if ret is None or ret < g["min_total_return_pct"]:
        fails.append(f"profit(total_return_pct) {ret} < {g['min_total_return_pct']}")
    dd = num("max_drawdown_pct")
    if dd is None or abs(dd) > g["max_drawdown_pct"]:
        fails.append(f"max_drawdown {dd} beyond {g['max_drawdown_pct']}")
    sh = num("sharpe_daily")
    if sh is None or sh < g["min_sharpe_daily"]:
        fails.append(f"sharpe_daily {sh} < {g['min_sharpe_daily']}")
    if g["require_validation_pass"] and run.get("validation_status") != "PASS":
        fails.append(f"validation={run.get('validation_status')}")
    return (not fails), fails


def composite_scores(rows, weights=None):
    """rows: [{'strategy_id', 'metrics': {...}}]. Har metric ko sabhi strategies ke beech min-max normalize karke
    weighted sum. 0..1 range, sirf is run ke andar relative. None metric wali row ko score None milta hai."""
    w = {**DEFAULT_WEIGHTS, **(weights or {})}

    def val(metrics, key):
        v = metrics.get(key)
        if v is None:
            return None
        # drawdown ऋणात्मक आता है; तुलना के लिए size (absolute) लेते हैं
        return abs(float(v)) if key == "max_drawdown_pct" else float(v)

    bounds = {}
    for key in w:
        vals = [val(r["metrics"], key) for r in rows if val(r["metrics"], key) is not None]
        if vals:
            bounds[key] = (min(vals), max(vals))
    scores = {}
    for r in rows:
        total, ok = 0.0, True
        for key, weight in w.items():
            v = val(r["metrics"], key)
            if v is None or key not in bounds:
                ok = False
                break
            lo, hi = bounds[key]
            norm = 0.5 if hi == lo else (v - lo) / (hi - lo)
            if DIRECTION.get(key, +1) < 0:
                norm = 1.0 - norm
            total += weight * norm
        scores[r["strategy_id"]] = round(total, 4) if ok else None
    return scores
