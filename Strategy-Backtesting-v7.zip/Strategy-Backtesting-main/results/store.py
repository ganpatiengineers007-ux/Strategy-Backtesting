"""SQLite results ledger. Har study run ek row (runs) + har strategy ka result (results).
Ek hi file: output/results.db (RESULTS_DB env se badal sakte ho)."""
import json
import os
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

SCHEMA = """
CREATE TABLE IF NOT EXISTS studies (
  study_id TEXT PRIMARY KEY, created_at TEXT, gates_json TEXT, weights_json TEXT,
  datasets_json TEXT, out_dir TEXT
);
CREATE TABLE IF NOT EXISTS results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  study_id TEXT NOT NULL REFERENCES studies(study_id),
  strategy_id TEXT NOT NULL, version TEXT, rank INTEGER, study_result TEXT, score REAL,
  datasets_run INTEGER, datasets_passed INTEGER, n_trades INTEGER, win_rate_pct REAL,
  expectancy REAL, total_return_pct REAL, max_drawdown_pct REAL, sharpe_daily REAL,
  validation TEXT, failures TEXT, display_name TEXT
);
CREATE INDEX IF NOT EXISTS ix_results_strategy ON results(strategy_id, study_id);
CREATE TABLE IF NOT EXISTS dataset_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  study_id TEXT NOT NULL REFERENCES studies(study_id),
  strategy_id TEXT NOT NULL, dataset_id TEXT, dataset_hash TEXT, bars INTEGER,
  engine_status TEXT, reason TEXT, validation_status TEXT, gate_pass INTEGER,
  metrics_json TEXT, validation_json TEXT
);
CREATE INDEX IF NOT EXISTS ix_druns_strategy ON dataset_runs(strategy_id, study_id);
"""


def db_path():
    return Path(os.getenv("RESULTS_DB") or ROOT / "output" / "results.db")


def connect(path=None):
    p = Path(path) if path else db_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(p), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    cols = {r[1] for r in conn.execute("PRAGMA table_info(results)")}
    if "display_name" not in cols:  # purane db ke liye
        conn.execute("ALTER TABLE results ADD COLUMN display_name TEXT")
        conn.commit()
    return conn


def record_study(conn, study_id, created_at, gates, weights, datasets, out_dir, rows, runs):
    with conn:
        conn.execute("INSERT OR REPLACE INTO studies VALUES (?,?,?,?,?,?)",
                     (study_id, created_at, json.dumps(gates), json.dumps(weights),
                      json.dumps(datasets), str(out_dir)))
        for r in rows:
            m = r.get("metrics") or {}
            conn.execute(
                "INSERT INTO results (study_id, strategy_id, version, rank, study_result, score, datasets_run,"
                " datasets_passed, n_trades, win_rate_pct, expectancy, total_return_pct, max_drawdown_pct,"
                " sharpe_daily, validation, failures, display_name) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (study_id, r["strategy_id"], r.get("version"), r.get("rank"), r["STUDY_RESULT"], r.get("score"),
                 r["datasets_run"], r["datasets_passed"], m.get("n_trades"), m.get("win_rate_pct"),
                 m.get("expectancy"), m.get("total_return_pct"), m.get("max_drawdown_pct"),
                 m.get("sharpe_daily"), r["validation"], r["failures"], r.get("display_name", "")))
        for x in runs:
            conn.execute(
                "INSERT INTO dataset_runs (study_id, strategy_id, dataset_id, dataset_hash, bars, engine_status,"
                " reason, validation_status, gate_pass, metrics_json, validation_json) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (study_id, x["strategy_id"], x.get("dataset_id"), x.get("dataset_hash"), x.get("bars"),
                 x.get("status"), x.get("reason"), x.get("validation_status"), int(bool(x.get("gate_pass"))),
                 json.dumps(x.get("metrics") or {}, default=str),
                 json.dumps(x.get("validation_checks") or {}, default=str)))


def strategy_history(conn, strategy_id):
    return [dict(r) for r in conn.execute(
        "SELECT s.created_at, r.* FROM results r JOIN studies s USING(study_id) "
        "WHERE r.strategy_id=? ORDER BY s.created_at", (strategy_id,)).fetchall()]


def all_latest(conn):
    return [dict(r) for r in conn.execute(
        "SELECT r.* FROM results r JOIN studies s USING(study_id) WHERE s.created_at = "
        "(SELECT MAX(created_at) FROM studies s2 JOIN results r2 USING(study_id) WHERE r2.strategy_id=r.strategy_id) "
        "ORDER BY r.strategy_id").fetchall()]
