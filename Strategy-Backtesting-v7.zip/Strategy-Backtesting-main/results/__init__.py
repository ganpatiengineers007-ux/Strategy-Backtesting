"""Results store: har study run ka itihaas SQLite me (strategy-wise, dataset-wise)."""
