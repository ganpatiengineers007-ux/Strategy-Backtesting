import tempfile
import unittest
from pathlib import Path

from backend.services import study_service as svc
from results import store


class StudyServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "r.db"
        conn = store.connect(self.db)
        row = {"strategy_id": "sweep", "version": "0.1.0", "rank": 1, "STUDY_RESULT": "FAIL", "score": 0.7,
               "datasets_run": 2, "datasets_passed": 0, "validation": "FAIL", "failures": "[d] profit",
               "metrics": {"n_trades": 900, "win_rate_pct": 35.0, "total_return_pct": 30.0,
                           "max_drawdown_pct": 14.0, "sharpe_daily": 1.9, "expectancy": 660.0}}
        runs = [{"strategy_id": "sweep", "dataset_id": "NSE_X_5", "dataset_hash": "abc", "bars": 100,
                 "status": "COMPLETED", "reason": "", "validation_status": "FAIL", "gate_pass": False,
                 "metrics": {"n_trades": 900}, "validation_checks": {"leakage": "PASS"}}]
        store.record_study(conn, "study-1", "2026-11-01T10:00:00", {"min_trades": 30}, {}, ["NSE_X_5.csv"],
                           "out/study-1", [row], runs)
        conn.close()

    def tearDown(self):
        self.tmp.cleanup()

    def test_latest_and_history(self):
        self.assertEqual(svc.latest_results(self.db)[0]["strategy_id"], "sweep")
        self.assertEqual(len(svc.strategy_history("sweep", self.db)), 1)
        self.assertEqual(svc.strategy_history("nope", self.db), [])

    def test_study_detail_and_missing(self):
        d = svc.study_detail("study-1", self.db)
        self.assertEqual(d["results"][0]["strategy_id"], "sweep")
        self.assertEqual(len(d["dataset_runs"]), 1)
        self.assertIsNone(svc.study_detail("study-404", self.db))

    def test_dataset_run_detail_parses_json(self):
        rows = svc.dataset_run_detail("study-1", "sweep", self.db)
        self.assertEqual(rows[0]["metrics"]["n_trades"], 900)
        self.assertEqual(rows[0]["validation_checks"]["leakage"], "PASS")

    def test_registry_overview_lists_real_strategies(self):
        reg = svc.registry_overview()
        ids = {s["strategy_id"] for s in reg["strategies"]}
        self.assertIn("sweep", ids)
        self.assertIn("obi_delta", ids)
        obi = next(s for s in reg["strategies"] if s["strategy_id"] == "obi_delta")
        self.assertIn("bid_depth", obi["required_data"])


if __name__ == "__main__":
    unittest.main()
