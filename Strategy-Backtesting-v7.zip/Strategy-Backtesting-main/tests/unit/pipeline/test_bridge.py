import unittest
from types import SimpleNamespace

import numpy as np

from strategies._bridge import PrecomputedLongAdapter, _epoch, not_wired


def bar(ts, c):
    return SimpleNamespace(ts=ts, open=c, high=c, low=c, close=c, volume=1.0)


class FakeCtx:
    def __init__(self, bars, index):
        self._bars, self.index, self.position = bars, index, 0


class ScriptedAdapter(PrecomputedLongAdapter):
    strategy_id = "scripted"

    def _positions(self, view):
        # 0,0,1,1,0,-1,1 -> entry at idx 2, exit at idx 4, short=no entry, entry at idx 6
        return np.array([0, 0, 1, 1, 0, -1, 1], dtype=float)


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.bars = [bar(f"2024-01-01T09:{15 + i:02d}:00", 100 + i) for i in range(7)]

    def test_entry_and_exit_transitions_only(self):
        a = ScriptedAdapter({})
        out = [a.on_bar(FakeCtx(self.bars, i)) for i in range(7)]
        self.assertIsNone(out[0]); self.assertIsNone(out[1])
        self.assertEqual(out[2].side, "BUY")
        self.assertIsNone(out[3])             # already long, no repeat BUY
        self.assertEqual(out[4].side, "EXIT")
        self.assertIsNone(out[5])             # short ignored in long-only engine
        self.assertEqual(out[6].side, "BUY")

    def test_positions_computed_once_per_series(self):
        calls = {"n": 0}

        class Counting(ScriptedAdapter):
            def _positions(self, view):
                calls["n"] += 1
                return super()._positions(view)

        a = Counting({})
        for i in range(7):
            a.on_bar(FakeCtx(self.bars, i))
        self.assertEqual(calls["n"], 1)

    def test_naive_ist_timestamp_converted_to_utc_epoch(self):
        # 2024-01-01 09:15 IST = 03:45 UTC = 1704080700
        self.assertEqual(int(_epoch("2024-01-01T09:15:00", "Asia/Kolkata")), 1704080700)

    def test_not_wired_raises_clear_error(self):
        with self.assertRaises(NotImplementedError) as cm:
            not_wired("obi_delta", ("bid_depth",))
        self.assertIn("obi_delta", str(cm.exception))
        self.assertIn("bid_depth", str(cm.exception))


if __name__ == "__main__":
    unittest.main()
