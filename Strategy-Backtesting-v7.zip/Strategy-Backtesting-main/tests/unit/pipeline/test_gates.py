import unittest

from pipeline.gates import DEFAULT_GATES, composite_scores, evaluate_gates


def good_metrics(**over):
    m = {"n_trades": 120, "win_rate_pct": 55.0, "expectancy": 12.5, "total_return_pct": 18.0,
         "max_drawdown_pct": -9.0, "sharpe_daily": 1.4}
    m.update(over)
    return m


def run(metrics=None, status="COMPLETED", validation="PASS"):
    return {"status": status, "reason": "", "validation_status": validation,
            "metrics": good_metrics() if metrics is None else metrics}


class GateTests(unittest.TestCase):
    def test_good_run_passes(self):
        ok, fails = evaluate_gates(run())
        self.assertTrue(ok, fails)

    def test_blocked_engine_fails(self):
        ok, fails = evaluate_gates(run(status="BLOCKED", metrics={}))
        self.assertFalse(ok)
        self.assertTrue(fails[0].startswith("engine=BLOCKED"))

    def test_too_few_trades_fails(self):
        ok, fails = evaluate_gates(run(good_metrics(n_trades=5)))
        self.assertFalse(ok)
        self.assertTrue(any("trades" in f for f in fails))

    def test_low_accuracy_fails(self):
        ok, fails = evaluate_gates(run(good_metrics(win_rate_pct=20.0)))
        self.assertFalse(ok)
        self.assertTrue(any("accuracy" in f for f in fails))

    def test_drawdown_uses_absolute_value(self):
        self.assertFalse(evaluate_gates(run(good_metrics(max_drawdown_pct=-35.0)))[0])
        self.assertTrue(evaluate_gates(run(good_metrics(max_drawdown_pct=-5.0)))[0])

    def test_loss_making_strategy_fails(self):
        ok, fails = evaluate_gates(run(good_metrics(total_return_pct=-3.0, expectancy=-1.0)))
        self.assertFalse(ok)
        self.assertTrue(any("profit" in f for f in fails))
        self.assertTrue(any("expectancy" in f for f in fails))

    def test_missing_metric_fails_not_passes(self):
        m = good_metrics()
        del m["sharpe_daily"]
        ok, fails = evaluate_gates(run(m))
        self.assertFalse(ok)
        self.assertTrue(any("sharpe" in f for f in fails))

    def test_validation_must_pass_when_required(self):
        self.assertFalse(evaluate_gates(run(validation="FAIL"))[0])
        self.assertTrue(evaluate_gates(run(validation="FAIL"), {"require_validation_pass": False})[0])

    def test_custom_threshold_overrides_default(self):
        self.assertEqual(DEFAULT_GATES["min_trades"], 30)
        self.assertFalse(evaluate_gates(run(good_metrics(n_trades=50)), {"min_trades": 100})[0])


class ScoreTests(unittest.TestCase):
    def test_better_strategy_scores_higher(self):
        rows = [
            {"strategy_id": "A", "metrics": good_metrics()},
            {"strategy_id": "B", "metrics": good_metrics(total_return_pct=2.0, sharpe_daily=0.2,
                                                         win_rate_pct=42.0, max_drawdown_pct=-18.0)},
        ]
        s = composite_scores(rows)
        self.assertGreater(s["A"], s["B"])
        self.assertGreaterEqual(s["A"], 0.0)
        self.assertLessEqual(s["A"], 1.0)

    def test_lower_drawdown_is_better(self):
        rows = [
            {"strategy_id": "shallow", "metrics": good_metrics(max_drawdown_pct=-4.0)},
            {"strategy_id": "deep", "metrics": good_metrics(max_drawdown_pct=-30.0)},
        ]
        s = composite_scores(rows, {"total_return_pct": 0, "sharpe_daily": 0, "win_rate_pct": 0,
                                    "max_drawdown_pct": 1.0})
        self.assertEqual(s["shallow"], 1.0)
        self.assertEqual(s["deep"], 0.0)

    def test_none_metric_gives_none_score(self):
        rows = [{"strategy_id": "A", "metrics": good_metrics()},
                {"strategy_id": "X", "metrics": good_metrics(sharpe_daily=None)}]
        self.assertIsNone(composite_scores(rows)["X"])

    def test_single_strategy_gets_midpoint(self):
        s = composite_scores([{"strategy_id": "solo", "metrics": good_metrics()}])
        self.assertAlmostEqual(s["solo"], 0.5, places=3)


if __name__ == "__main__":
    unittest.main()
