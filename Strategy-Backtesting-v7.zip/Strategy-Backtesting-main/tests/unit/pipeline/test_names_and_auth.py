import tempfile
import unittest
from pathlib import Path
from unittest import mock

from registry import names
from backend.services import auth


class NamesTests(unittest.TestCase):
    def test_pool_is_unique_and_big_enough(self):
        self.assertEqual(len(names.POOL), len(set(names.POOL)))
        self.assertGreaterEqual(len(names.POOL), 50)

    def test_assignment_is_stable_and_unique(self):
        with tempfile.TemporaryDirectory() as d:
            with mock.patch.object(names, "LEDGER", Path(d) / "n.json"):
                first = names.assign_all(["fvg", "sweep"])
                again = names.assign_all(["fvg", "sweep", "gamma_vwap"])
                self.assertEqual(first["fvg"], again["fvg"])          # ek baar tay, badalta nahi
                self.assertNotEqual(again["fvg"], again["sweep"])     # dobara nahi
                self.assertNotEqual(again["gamma_vwap"], again["fvg"])

    def test_bad_ids_rejected(self):
        for bad in ["S1", "Fvg", "my strategy", "1abc", "ab"]:
            with self.assertRaises(ValueError):
                names.validate_id(bad)
        self.assertEqual(names.validate_id("gamma_vwap"), "gamma_vwap")


class AuthTests(unittest.TestCase):
    def test_hash_and_verify(self):
        h = auth.hash_password("correct-horse")
        self.assertTrue(auth.verify_password("correct-horse", h))
        self.assertFalse(auth.verify_password("wrong", h))
        self.assertNotIn("correct-horse", h)

    def test_login_flow_and_expiry(self):
        with tempfile.TemporaryDirectory() as d:
            with mock.patch.object(auth, "USERS", Path(d) / "u.json"):
                auth.add_user("admin", "longpassword1")
                self.assertIsNone(auth.login("admin", "bad"))
                tok = auth.login("admin", "longpassword1")
                self.assertEqual(auth.check_token(tok), "admin")
                auth.logout(tok)
                self.assertIsNone(auth.check_token(tok))
                tok2 = auth.login("admin", "longpassword1")
                with mock.patch.object(auth.time, "time", return_value=auth.time.time() + auth.TTL + 5):
                    self.assertIsNone(auth.check_token(tok2))

    def test_short_password_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            with mock.patch.object(auth, "USERS", Path(d) / "u.json"):
                with self.assertRaises(ValueError):
                    auth.add_user("x", "short")


if __name__ == "__main__":
    unittest.main()
