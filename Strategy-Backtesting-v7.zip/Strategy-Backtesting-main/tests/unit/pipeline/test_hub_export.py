import csv
import sqlite3
import tempfile
import unittest
from pathlib import Path

from pipeline.hub_export import export_all, export_candles, list_pairs, safe_name

# 1704067200 = 2024-01-01 00:00 UTC = 05:30 IST
TS0 = 1704067200


def make_db(path):
    conn = sqlite3.connect(str(path))
    conn.executescript("""
        CREATE TABLE candles (symbol TEXT NOT NULL, tf TEXT NOT NULL, ts INTEGER NOT NULL,
          open REAL, high REAL, low REAL, close REAL, volume REAL, derived INTEGER DEFAULT 0,
          PRIMARY KEY (symbol, tf, ts)) WITHOUT ROWID;""")
    rows = [("NSE:NIFTY50-INDEX", "5", TS0, 100, 101, 99, 100.5, 1000, 0),
            ("NSE:NIFTY50-INDEX", "5", TS0 + 300, 100.5, 102, 100, 101.5, 1200, 0),
            ("NSE:NIFTY50-INDEX", "15", TS0, 100, 103, 99, 102, 3000, 1),
            ("NSE:SBIN-EQ", "5", TS0, 500, 505, 498, 503, None, 0)]
    conn.executemany("INSERT INTO candles VALUES (?,?,?,?,?,?,?,?,?)", rows)
    conn.commit()
    conn.close()


class HubExportTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Path(self.tmp.name) / "hub.db"
        make_db(self.db)
        self.out = Path(self.tmp.name) / "out"

    def tearDown(self):
        self.tmp.cleanup()

    def test_list_pairs_counts(self):
        pairs = {(s, t): n for s, t, n in list_pairs(self.db)}
        self.assertEqual(pairs[("NSE:NIFTY50-INDEX", "5")], 2)
        self.assertEqual(pairs[("NSE:NIFTY50-INDEX", "15")], 1)

    def test_export_converts_epoch_to_ist_and_keeps_order(self):
        export_candles(self.db, "NSE:NIFTY50-INDEX", "5", self.out / "x.csv", tz="Asia/Kolkata")
        with open(self.out / "x.csv", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        self.assertEqual(list(rows[0].keys()), ["ts", "open", "high", "low", "close", "volume"])
        self.assertEqual(rows[0]["ts"], "2024-01-01T05:30:00")
        self.assertEqual(rows[1]["ts"], "2024-01-01T05:35:00")
        self.assertEqual(rows[1]["close"], "101.5")

    def test_null_volume_becomes_zero(self):
        export_candles(self.db, "NSE:SBIN-EQ", "5", self.out / "s.csv")
        with open(self.out / "s.csv", encoding="utf-8") as f:
            self.assertEqual(list(csv.DictReader(f))[0]["volume"], "0")

    def test_export_all_writes_one_file_per_pair_with_safe_names(self):
        res = export_all(self.db, self.out)
        self.assertEqual(len(res), 3)
        names = sorted(Path(r["path"]).name for r in res)
        self.assertIn("NSE_NIFTY50-INDEX_5.csv", names)
        self.assertIn("NSE_SBIN-EQ_5.csv", names)

    def test_export_all_filters(self):
        res = export_all(self.db, self.out, tf="15")
        self.assertEqual([r["tf"] for r in res], ["15"])
        res = export_all(self.db, self.out, symbol="NSE:SBIN-EQ")
        self.assertEqual([r["symbol"] for r in res], ["NSE:SBIN-EQ"])

    def test_safe_name(self):
        self.assertEqual(safe_name("NSE:NIFTY50-INDEX", "5"), "NSE_NIFTY50-INDEX_5")


if __name__ == "__main__":
    unittest.main()
