import tempfile
import unittest
from pathlib import Path

from results import store


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.conn = store.connect(Path(self.tmp.name) / "r.db")

    def tearDown(self):
        self.conn.close()
        self.tmp.cleanup()

    def _rows(self, sid, ret, result="PASS"):
        return [{"strategy_id": sid, "version": "0.1.0", "rank": 1, "STUDY_RESULT": result, "score": 0.5,
                 "datasets_run": 1, "datasets_passed": 1, "validation": "PASS", "failures": "",
                 "metrics": {"n_trades": 40, "win_rate_pct": 50.0, "total_return_pct": ret,
                             "max_drawdown_pct": 5.0, "sharpe_daily": 1.0, "expectancy": 3.0}}]

    def test_history_keeps_every_run(self):
        for i, ret in enumerate([2.0, -1.5]):
            sid_study = f"study-{i}"
            store.record_study(self.conn, sid_study, f"2026-11-0{i+1}T00:00:00", {}, {}, ["d.csv"], "x",
                               self._rows("sweep", ret), [])
        hist = store.strategy_history(self.conn, "sweep")
        self.assertEqual([h["total_return_pct"] for h in hist], [2.0, -1.5])

    def test_latest_per_strategy(self):
        store.record_study(self.conn, "s1", "2026-11-01T00:00:00", {}, {}, [], "x", self._rows("a", 1.0), [])
        store.record_study(self.conn, "s2", "2026-11-02T00:00:00", {}, {}, [], "x", self._rows("a", 9.0, "FAIL"), [])
        latest = store.all_latest(self.conn)
        self.assertEqual(len(latest), 1)
        self.assertEqual(latest[0]["total_return_pct"], 9.0)

    def test_dataset_runs_stored(self):
        runs = [{"strategy_id": "a", "dataset_id": "d", "dataset_hash": "h", "bars": 10, "status": "BLOCKED",
                 "reason": "MISSING_DATA:x", "validation_status": "BLOCKED", "gate_pass": False, "metrics": {}}]
        store.record_study(self.conn, "s9", "2026-11-03T00:00:00", {}, {}, [], "x", [], runs)
        n = self.conn.execute("SELECT COUNT(*) FROM dataset_runs WHERE study_id='s9'").fetchone()[0]
        self.assertEqual(n, 1)


if __name__ == "__main__":
    unittest.main()
